import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ModalController , ActionSheetController, AlertController } from '@ionic/angular';
import { UserServiceService } from '../user-service.service';
import { ProdcutServiceService } from 'src/app/prodcut-service.service';
import { PaymentService } from 'src/app/new-payment/payment.service';
import { PlanService } from 'src/app/new-plan/plan.service';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';
import { ImagePickerComponent } from 'src/app/shared/image-picker/image-picker.component';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { Router } from '@angular/router';

function base64toBlob(base64Data, contentType) {
  contentType = contentType || '';
  const sliceSize = 1024;
  const byteCharacters = window.atob(base64Data);
  const bytesLength = byteCharacters.length;
  const slicesCount = Math.ceil(bytesLength / sliceSize);
  const byteArrays = new Array(slicesCount);

  for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
    const begin = sliceIndex * sliceSize;
    const end = Math.min(begin + sliceSize, bytesLength);

    const bytes = new Array(end - begin);
    for (let offset = begin, i = 0; offset < end; ++i, ++offset) {
      bytes[i] = byteCharacters[offset].charCodeAt(0);
    }
    byteArrays[sliceIndex] = new Uint8Array(bytes);
  }
  return new Blob(byteArrays, { type: contentType });
}


@Component({
  selector: 'app-newuser-add',
  templateUrl: './newuser-add.component.html',
  styleUrls: ['./newuser-add.component.scss'],
})
export class NewuserAddComponent implements OnInit , OnDestroy {

  productList: any;
  paymentList: any;
  planList: any;
  imageFile: Blob;
  idProof: Blob;

  private subscriptionObj: Subscription;
  @ViewChild('f') form: NgForm;

  constructor(private modalCtrl: ModalController,
              private userService: UserServiceService ,
              private productService: ProdcutServiceService ,
              private paymentService: PaymentService,
              private planService: PlanService,
              private camera: Camera,
              private actionSheetCtrl: ActionSheetController,
              private imagePicker: ImagePicker,
              private alertCtrl: AlertController,
              private router: Router,
    ) { }

  ngOnInit() {
      this.subscriptionObj = this.productService.getProductsDetail
      .subscribe(productList => {
          console.log('productList ' + JSON.stringify(productList));
          this.productList = productList;
      });


      this.subscriptionObj = this.paymentService.getPaymentDetails
      .subscribe(paymentList => {
          console.log('paymentList ' + JSON.stringify(paymentList));
          this.paymentList = paymentList;
      });


      this.subscriptionObj = this.planService.getPlansDetail
      .subscribe(planList => {
          console.log('planList ' + JSON.stringify(planList));
          this.planList = planList;
      });
    }

  onCancelAddUser() {
    console.log('Call From Add User Model Ts');
    this.modalCtrl.dismiss(null , 'cancel');
  }

  addUser() {
    if (!this.form.valid || !this.imageFile)  {
      this.alert(` Please Select User Image First !! `);
      return;
    } else if ( !this.idProof) {
      this.alert(` Please Select User Id Proof !! `);
      return;
    }

    this.modalCtrl.dismiss(
      {
        userDetail: {
          userName: this.form.value['userNameModel'],
          userMobile: this.form.value['userMobilenumberModel'],
          userEmail: this.form.value['useEmailModel'],
          userAddress: this.form.value['userAddressModel'],
          userDob: this.form.value['userDobModel'],
          userChooseProduct: this.form.value['productNameModel'],
          userPlan: this.form.value['planNameModel'],
          userPaymentMode: this.form.value['paymentNameModel'],
          userRegistrationDate: this.form.value['userRegModel'],
          userImg : this.imageFile,
          userIdProof: this.idProof
        }
      },
      'confirm'
    );
  }

  onIdPicked(idData: string | File) {
    if (typeof idData === 'string') {
      try {
        this.idProof = base64toBlob(
          idData.replace('data:image/jpeg;base64,', ''),
          'image/jpeg'
        );
        console.log('Akshay Image Data change to file');
        console.log(this.idProof);
      } catch (error) {
        console.log(error);
        return;
      }
    } else {
      this.idProof = idData;
    }

   // this.form.patchValue({ image: imageFile });
  }

  // onImagePic() {

  //   this.actionSheetCtrl
  //   .create({
  //     header: 'Choose an Action',
  //     buttons: [
  //       {
  //         text: ' Open Camera',
  //         handler: () => {
  //           const options: CameraOptions = {
  //             quality: 100,
  //             destinationType: this.camera.DestinationType.FILE_URI,
  //             encodingType: this.camera.EncodingType.JPEG,
  //             mediaType: this.camera.MediaType.PICTURE
  //           }
  //           this.camera.getPicture(options).then((imageData) => {
  //            // imageData is either a base64 encoded string or a file URI
  //            // If it's base64 (DATA_URL):
  //            let base64Image = 'data:image/jpeg;base64,' + imageData;
  //           }, (err) => {
  //            // Handle error
  //           });
  //         }
  //       },
  //       {
  //         text: 'Open Gallary',
  //         handler: () => {
  //           const options = {
  //             quality: 100,
  //             maximumImagesCount: 1,
  //             outputType: 1
  //           };
  //           this.imagePicker.getPictures(options).then((results) => {
  //             // tslint:disable-next-line: prefer-for-of
  //             // implementation(project(path: ":CordovaLib"))
  //             // implementation "com.android.support:support-v4:23.+"
  //             // implementation "com.android.support:support-annotations:27.+"
  //             // implementation "com.android.support:appcompat-v7:23+"
  //             for (let i = 0; i < results.length; i++) {
  //               console.log('CHANGES AKSHAY CALL :: ' + results[i]);
  //                 console.log('Image URI: ' + results[i]);
  //             }
  //           }, (err) => { });
  //         }
  //       },
  //       {
  //         text: 'Cancel',
  //         role: 'cancel'
  //       }
  //     ]
  //   })
  //   .then(actionSheetEl => {
  //     actionSheetEl.present();
  //   });
  // }

  onImagePicked(imageData: string | File) {
    if (typeof imageData === 'string') {
      try {
        this.imageFile = base64toBlob(
          imageData.replace('data:image/jpeg;base64,', ''),
          'image/jpeg'
        );
        console.log('Akshay Image Data change to file');
        console.log(this.imageFile);
      } catch (error) {
        console.log(error);
        return;
      }
    } else {
      this.imageFile = imageData;
    }

   // this.form.patchValue({ image: imageFile });
  }


  alert(str: string) {
    this.alertCtrl
    .create({
      header : 'VALIDATE',
      message: str,
      buttons: [
        {
         text: 'OK',
         handler: () => {
         //navigator['app'].exitApp();
         }
       }
     ],
     backdropDismiss : false
    })
    .then(alertEl => {
      alertEl.present();
    });
  }


  onAddMethod(name: string) {

   if (name === 'Product') {
    this.modalCtrl.dismiss(null , 'cancel');
    this.router.navigate(['/new-product']);
   }

   if (name === 'Payment') {
    this.modalCtrl.dismiss(null , 'cancel');
    this.router.navigate(['/new-payment']);
   }

   if (name === 'Plan') {
    this.modalCtrl.dismiss(null , 'cancel');
    this.router.navigate(['/new-plan']);
   }
  }

  ngOnDestroy() {
    if (this.subscriptionObj ) {
        this.subscriptionObj.unsubscribe();
    }
  }
}

export class User {
    constructor(
        public userId: string,
        public userName: string,
        public userMobile: string,
        public userEmail: string,
        public userAddress: string,
        public userDob: string,
        public userImg: string,
        public userIdProof: string,
        public userChooseProduct: string,
        public userPlan: string,
        public userPaymentMode: string,
        public userRegistrationDate: string,
        public loginUserId: string
        ) {}
 }

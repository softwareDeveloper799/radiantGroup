import { Component, OnInit, OnDestroy } from '@angular/core';
import { User } from '../user.model';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, LoadingController, AlertController } from '@ionic/angular';
import { UserServiceService } from '../user-service.service';
import { ProdcutServiceService } from 'src/app/prodcut-service.service';
import { PaymentService } from 'src/app/new-payment/payment.service';
import { PlanService } from 'src/app/new-plan/plan.service';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.page.html',
  styleUrls: ['./edituser.page.scss'],
})
export class EdituserPage implements OnInit , OnDestroy {
  userId: any;
  user: User;
  private subscriptionObj: Subscription;
  form: FormGroup;
  isLoading = false;
  imgUrl: string;
  userIdProofUrl: string;
  userChooseProduct: string;
  productList: any;
  paymentList: any;
  planList: any;


  constructor(private route: ActivatedRoute,
              private userService: UserServiceService,
              private navCtrl: NavController,
              private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private productService: ProdcutServiceService,
              private paymentService: PaymentService,
              private planService: PlanService,
              private loginService: LoginService
    ) { }

  ngOnInit() {

    this.subscriptionObj = this.productService.getProductsDetail
    .subscribe(productList => {
        console.log('productList ' + JSON.stringify(productList));
        this.productList = productList;
    });


    this.subscriptionObj = this.paymentService.getPaymentDetails
    .subscribe(paymentList => {
        console.log('paymentList ' + JSON.stringify(paymentList));
        this.paymentList = paymentList;
    });


    this.subscriptionObj = this.planService.getPlansDetail
    .subscribe(planList => {
        console.log('planList ' + JSON.stringify(planList));
        this.planList = planList;
    });


    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('userId')) {
       console.log('Not Found..');
       return;
      }
      this.isLoading = true;
      this.userId = paramMap.get('userId');
      console.log('this.userId ' + this.userId);
      this.subscriptionObj = this.userService.getSingleUserDetail(this.userId)
      .subscribe(
        user => {
          this.imgUrl = user.userImg;
          this.userIdProofUrl = user.userIdProof;
          this.userChooseProduct = user.userChooseProduct;

          this.form = new FormGroup({
            userName: new FormControl(user.userName, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userMobile: new FormControl(user.userMobile, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userEmail: new FormControl(user.userEmail, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userAddress: new FormControl(user.userAddress, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userDob: new FormControl(user.userDob, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userChooseProduct: new FormControl(user.userChooseProduct, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userPlan: new FormControl(user.userPlan, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userPaymentMode: new FormControl(user.userPaymentMode, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            userRegistrationDate: new FormControl(user.userRegistrationDate, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
          });
          this.isLoading = false;
        },
        error => {
          this.alertCtrl
            .create({
              header: 'An error occurred!',
              message: 'User Detail could not be fetched. Please try again later.',
              buttons: [
                {
                  text: 'Okay',
                  handler: () => {
                   this.router.navigate(['/dashboard']);
                  }
                }
              ]
            })
            .then(alertEl => {
              alertEl.present();
            });
        }
      );
    });
  }

  updateUser() {
    if (!this.form.valid) {
      return;
    }
    this.loadingCtrl
      .create({
        message: 'Updating user...'
      })
      .then(loadingEl => {
        loadingEl.present();
        this.userService.updateUser(
            this.userId,
            this.form.value.userName ,
            this.form.value.userMobile,
            this.form.value.userEmail,
            this.form.value.userAddress ,
            this.form.value.userDob,
            this.imgUrl,
            this.userIdProofUrl,
            this.form.value.userChooseProduct,
            this.form.value.userPlan,
            this.form.value.userPaymentMode,
            this.form.value.userRegistrationDate,
            this.loginService.login()
          )
          .subscribe(() => {
            loadingEl.dismiss();
            this.form.reset();
            this.router.navigate(['/new-user']);
          });
      });
  }

  ngOnDestroy() {
    if (this.subscriptionObj) {
      this.subscriptionObj.unsubscribe();
    }
  }
}

import { Component, OnInit, OnDestroy } from '@angular/core';
import { ModalController, LoadingController } from '@ionic/angular';
import { NewuserAddComponent } from './newuser-add/newuser-add.component';
import { Subscription } from 'rxjs';
import { UserServiceService } from './user-service.service';
import { switchMap, tap } from 'rxjs/operators';
import { ProdcutServiceService } from '../prodcut-service.service';
import { PaymentService } from '../new-payment/payment.service';
import { PlanService } from '../new-plan/plan.service';
import { LoginService } from '../login/login.service';
import { DashboardService } from '../admin-dashboard/dashboard.service';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.page.html',
  styleUrls: ['./new-user.page.scss'],
})
export class NewUserPage implements OnInit , OnDestroy{

  userList: any;
  isLoading = false;
  private subscriptionObj: Subscription;

  constructor( private modalCtrl: ModalController,
               private loadingCtrl: LoadingController,
               private userService: UserServiceService,
               private productService: ProdcutServiceService ,
               private paymentService: PaymentService,
               private planService: PlanService,
               private loginService: LoginService,
               private dashboardService: DashboardService
    ) { }

    ngOnInit() {
      this.subscriptionObj = this.userService.getUsersDetails
        .subscribe(userDetails => {
            console.log('userDetails ' + JSON.stringify(userDetails));
            this.userList = userDetails;
        });
    }

    ionViewWillEnter() {
       this.isLoading = true;
       this.userService.fetchUserList(this.loginService.login()).subscribe(() => {
        this.productService.fetchProducts(this.loginService.login()).subscribe(() =>{
          this.planService.fetchPlan(this.loginService.login()).subscribe(() =>{
            this.paymentService.fetchPayment(this.loginService.login()).subscribe(() =>{
              this.isLoading = false;
            });
          });
        });
      });
    }

  onAddUser() {
       console.log(`Enter Update Select`);
       let userImageUrl = null;
       this.modalCtrl
       .create({
         component: NewuserAddComponent,
         componentProps: { value : 123}
       })
       .then(modalEl => {
         modalEl.present();
         return modalEl.onDidDismiss();
       })
       .then(resultData => {
         console.log(`Enter Here ` + JSON.stringify(resultData));
         if (resultData.data != null) {
           this.loadingCtrl
          .create({
            message: 'Adding user...'
          })
          .then(loadingEl => {
            loadingEl.present();
            if (resultData.data != null) {
              this.userService.uploadUserImage(resultData.data.userDetail.userImg).pipe(tap(uploadRes => {
                    userImageUrl =  uploadRes.imageUrl;
                    this.userService.uploadUserImage(resultData.data.userDetail.userIdProof).pipe(switchMap(uploadIdPrrof => {
                      this.dashboardService.addDashBoardBarChartData_ONE();
                      return this.userService.addNewUser
                      (
                          resultData.data.userDetail.userName,
                          resultData.data.userDetail.userMobile,
                          resultData.data.userDetail.userEmail,
                          resultData.data.userDetail.userAddress,
                          resultData.data.userDetail.userDob,
                          userImageUrl,
                          uploadIdPrrof.imageUrl,
                          resultData.data.userDetail.userChooseProduct,
                          resultData.data.userDetail.userPlan,
                          resultData.data.userDetail.userPaymentMode,
                          resultData.data.userDetail.userRegistrationDate,
                          this.loginService.login()
                       );

                       })).subscribe(() => {
                        loadingEl.dismiss();
                    });
               })).subscribe(() => {

              });
              }
           });
          }
       });
     }

     onedit(user: any , slidingItem) {
      console.log('OnEdit :: ' + JSON.stringify(user));
      slidingItem.close();
    }

    ondelete(user: any ,  slidingItem) {
     console.log('OnDelete :: ' + JSON.stringify(user));
     slidingItem.close();
    }

     ngOnDestroy() {
      if (this.subscriptionObj ) {
          this.subscriptionObj.unsubscribe();
      }
    }
}

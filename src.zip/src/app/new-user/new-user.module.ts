import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { NewUserPage } from './new-user.page';
import { NewuserAddComponent } from './newuser-add/newuser-add.component';
import { ImagePickerComponent } from '../shared/image-picker/image-picker.component';
import { Camera } from '@ionic-native/camera/ngx';
import { IdProofPickerComponent } from '../shared/id-proof-picker/id-proof-picker.component';

const routes: Routes = [
  {
    path: '',
    component: NewUserPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [NewUserPage , NewuserAddComponent , ImagePickerComponent, IdProofPickerComponent],
  entryComponents: [NewuserAddComponent , ImagePickerComponent , IdProofPickerComponent]
})
export class NewUserPageModule {}

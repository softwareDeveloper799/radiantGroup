import { Injectable } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';
import { User } from './user.model';
import { tap, switchMap, take, map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

interface UserInterface {
  userName: string;
  userMobile: string;
  userEmail: string;
  userAddress: string;
  userDob: string;
  userImg: string;
  userIdProof: string;
  userChooseProduct: string;
  userPlan: string;
  userPaymentMode: string;
  userRegistrationDate: string;
  loginUserId: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
      private _user = new BehaviorSubject<User[]>([
      //   new User ('0', 'Mark Anthony', '9876754653', 'mark_anthony@gmail.com'
      //   , 'A-1, wall street new mall road LA.' , '12/12/1993' , 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_S9DUg_S9CHf-DxgcNbxYzZmibzud95wxTQslnreREOxA1ch1',
      //   'Membership' ,'Monthly' , 'Cash' , '7-8-2019'
      // ),
      // new User( '1', 'Anna Hathway',  '9345213211',  'anna_hathway@rediff.com'
      // ,  'A-1, wall street new mall road LA.',  '12/12/1993' ,  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_S9DUg_S9CHf-DxgcNbxYzZmibzud95wxTQslnreREOxA1ch1',
      //  'Membership' ,  'Monthly' ,  'Cash' , '7-8-2019'
      //  )
      ]);

      constructor(private http: HttpClient) { }

      get getUsersDetails() {
        return this._user.asObservable();
      }

      fetchUserList(userId: string) {
        // tslint:disable-next-line: max-line-length
        return this.http.get<{[key: string]: UserInterface}>(`https://subscriptionmanagementservice.firebaseio.com/user-details.json?orderBy="loginUserId"&equalTo=${userId}`)
        .pipe(map(resData => {
          const ProductArray = [];
          for (const key in resData) {
             if ( resData.hasOwnProperty(key)) {
               ProductArray.push(new User(
                 key,
                 resData[key].userName ,
                 resData[key].userMobile ,
                 resData[key].userEmail ,
                 resData[key].userAddress,
                 resData[key].userDob,
                 resData[key].userImg,
                 resData[key].userIdProof,
                 resData[key].userChooseProduct,
                 resData[key].userPlan,
                 resData[key].userPaymentMode,
                 resData[key].userRegistrationDate,
                 resData[key].loginUserId,
                 ));
             }
           }
          return ProductArray;
       // return [];
        }),
        tap(resArrayFromMap => {
          this._user.next(resArrayFromMap);
         })
        );
      }

      uploadUserImage(userimage: File) {
        const uploadData = new FormData();
        uploadData.append('userImage', userimage );
        // tslint:disable-next-line: max-line-length
        return this.http.post<{imageUrl: string, imagePath: string}>('https://us-central1-subscriptionmanagementservice.cloudfunctions.net/storeImage',
        uploadData);

      }

      addNewUser(userName: string , userMobile: string , userEmail: string,
                 userAddress: string , userDob: string, userImg: string, userIdProof: string , userChooseProduct: string,
                 userPlan: string, userPaymentMode: string , userRegistrationDate: string, loginUserId: string
        ) {
        const newUser = new User(
        Math.random().toString(),
         userName,
         userMobile,
         userEmail,
         userAddress,
         userDob,
         userImg,
         userIdProof,
         userChooseProduct,
         userPlan,
         userPaymentMode,
         userRegistrationDate,
         loginUserId
        );
        console.log('newUser : ' + JSON.stringify(newUser));
        let generatedId: string;

         // tslint:disable-next-line: max-line-length
        return  this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/user-details.json', {...newUser , id: null})
                .pipe(
                   switchMap(resData => {
                     generatedId = resData.name;
                     return this.getUsersDetails;
                   }),
                   take(1),
                   tap(user => {
                       console.log(' this._places 1 : ');
                       newUser.userId =  generatedId;
                       this._user.next(user.concat(newUser));
                    })
                );
      }

      getSingleUserDetail(id: string) {
        // return this.getUsersDetails.pipe(
        // take(1),
        // map(user => {
        //   return { ...user.find(p => p.userId === id) };
        // })
        // );
        return this.http.get<UserInterface>(`https://subscriptionmanagementservice.firebaseio.com/user-details/${id}.json`
        ).pipe(
          // tslint:disable-next-line: no-shadowed-variable
          map(UserDataForOne => {
            return new User (
                id,
                UserDataForOne.userName,
                UserDataForOne.userMobile,
                UserDataForOne.userEmail,
                UserDataForOne.userAddress,
                UserDataForOne.userDob,
                UserDataForOne.userImg,
                UserDataForOne.userIdProof,
                UserDataForOne.userChooseProduct,
                UserDataForOne.userPlan,
                UserDataForOne.userPaymentMode,
                UserDataForOne.userRegistrationDate,
                UserDataForOne.loginUserId
              );
            })
          );
      }

      updateUser(userID: string, userName: string , userMobile: string , userEmail: string,
                 userAddress: string , userDob: string, userImg: string, userIdProof: string , userChooseProduct: string,
                 userPlan: string, userPaymentMode: string , userRegistrationDate: string,
                 loginUserId: string
           ) {

        let updatedPrpduct: User[];
        return this._user.pipe(
           take(1),
           switchMap(products => {
            if ( !products || products.length <= 0) {
              return this.fetchUserList(loginUserId);
            } else {
              return of(products);
            }
          }),
          switchMap((user) => {
            const updatedUserIndex = user.findIndex(pl => pl.userId === userID);
            updatedPrpduct = [...user];
            const oldPlace = updatedPrpduct[updatedUserIndex];
            updatedPrpduct[updatedUserIndex] = new User(
              oldPlace.userId,
              userName,
              userMobile,
              userEmail,
              userAddress,
              userDob,
              userImg,
              userIdProof,
              userChooseProduct,
              userPlan,
              userPaymentMode,
              userRegistrationDate,
              loginUserId
            );
            return this.http.put(`https://subscriptionmanagementservice.firebaseio.com/user-details/${userID}.json`,
               {... updatedPrpduct[updatedUserIndex] , id: null}
              );
            }),
            tap((resData) => {
            this._user.next(updatedPrpduct);
          }));
      }


      onDeleteUser(userId: string) {
        return this.http.delete(`https://subscriptionmanagementservice.firebaseio.com/user-details/${userId}.json`
        ).pipe(
          switchMap(() => {
          return this.getUsersDetails;
        }),
          take(1),
          tap(products => {
            this._user.next(products.filter(b => b.userId !== userId));
        }));
      }
}

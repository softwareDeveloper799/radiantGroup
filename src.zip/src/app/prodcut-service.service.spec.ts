import { TestBed } from '@angular/core/testing';

import { ProdcutServiceService } from './prodcut-service.service';

describe('ProdcutServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProdcutServiceService = TestBed.get(ProdcutServiceService);
    expect(service).toBeTruthy();
  });
});

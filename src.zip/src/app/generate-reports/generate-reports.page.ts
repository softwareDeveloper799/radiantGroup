import { Component, OnInit, OnDestroy } from '@angular/core';
import { SegmentChangeEventDetail } from '@ionic/core';
import { UserServiceService } from '../new-user/user-service.service';
import { PaymentService } from '../new-payment/payment.service';
import { Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';
import { PlanService } from '../new-plan/plan.service';
import { AcceptPaymentService } from '../accept-payment/accept-payment.service';


@Component({
  selector: 'app-generate-reports',
  templateUrl: './generate-reports.page.html',
  styleUrls: ['./generate-reports.page.scss'],
})
export class GenerateReportsPage implements OnInit {

  isLoading = false;
  userPaymentList: any;
  private subscriptionObj: Subscription;


  constructor(private userService: UserServiceService,
              private paymentService: PaymentService,
              private loginService: LoginService,
              private acceptPaymentService: AcceptPaymentService,
              private planService: PlanService
    ) { }

  ngOnInit() {

    this.subscriptionObj = this.acceptPaymentService.getAcceptPaymentDetails
         .subscribe(acceptPaymentList => {
             console.log('userPaymentList ' + JSON.stringify(acceptPaymentList));
             this.userPaymentList = acceptPaymentList;
         });
  }

  ionViewWillEnter() {
    this.isLoading = true;
    this.acceptPaymentService.fetchAcceptPayment(this.loginService.login()).subscribe(() => {
      this.isLoading = false;
    });
  }


}

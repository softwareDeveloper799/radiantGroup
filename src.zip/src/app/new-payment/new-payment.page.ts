import { Component, OnInit } from '@angular/core';
import { ModalController, LoadingController } from '@ionic/angular';
import { NewpaymentAddComponent } from './newpayment-add/newpayment-add.component';
import { PaymentService } from './payment.service';
import { Subscribable, Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-new-payment',
  templateUrl: './new-payment.page.html',
  styleUrls: ['./new-payment.page.scss'],
})
export class NewPaymentPage implements OnInit {
  
  isLoading = false;
  paymentTypeArray: any;
  private subscriptionObj: Subscription;
  constructor(private modalCtrl: ModalController, private paymentService: PaymentService,
              private loadingCtrl: LoadingController,
              private loginService: LoginService) { }

  ngOnInit() {
    this.subscriptionObj = this.paymentService.getPaymentDetails
    .subscribe(planDetail => {
      console.log('planDetail ' + JSON.stringify(planDetail));
      this.paymentTypeArray = planDetail;
    });
  }

  ionViewWillEnter() {
    this.isLoading = true;
    this.paymentService.fetchPayment(this.loginService.login()).subscribe(() => {
      this.isLoading = false;
    });
  }

  onPaymentModeAdd(){
    console.log(`Enter Update Select onPaymentModeAdd`);
    // this.modalCtrl
    //    .create({
    //      component: NewpaymentAddComponent,
    //      componentProps: { value : 123}
    //    })
    //    .then(modalEl => {
    //      modalEl.present();
    //      return modalEl.onDidDismiss();
    //    })
    //    .then(resultData => {
    //      console.log(`Enter Here New Plan Add` + JSON.stringify(resultData));
    //      this.paymentTypeArray.push(resultData.data.paymentDetail);
    //    });


    this.modalCtrl
       .create({
         component: NewpaymentAddComponent,
         componentProps: { value : 123}
       })
       .then(modalEl => {
         modalEl.present();
         return modalEl.onDidDismiss();
       })
       .then(resultData => {
         console.log(`Enter Here ` + JSON.stringify(resultData));
         if (resultData.data != null) {
           this.loadingCtrl
          .create({
            message: 'Adding Payment Mode...'
          })
          .then(loadingEl => {
            loadingEl.present();
            console.log(`Enter Here New Payment Add` + JSON.stringify(resultData));
            this.paymentService.addNewPayment(
                    resultData.data.paymentDetail.paymentName ,
                    resultData.data.paymentDetail.paymentDesc ,
                    this.loginService.login()
              ).subscribe(() => {
                loadingEl.dismiss();
              });
           });
          }
       });

     }

     
    onPaymentModeedit(paymentDetail , slidingItem){
      console.log('onPaymentModeedit :: ' + JSON.stringify(paymentDetail));
      slidingItem.close();
    }

    onPaymentModeDelete(paymentDetail , slidingItem){
     console.log('onPaymentModeDelete :: ' + JSON.stringify(paymentDetail));
     slidingItem.close();
    }

}

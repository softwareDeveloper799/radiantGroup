import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { NewPaymentPage } from './new-payment.page';
import { NewpaymentAddComponent } from './newpayment-add/newpayment-add.component';

const routes: Routes = [
  {
    path: '',
    component: NewPaymentPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [NewPaymentPage,NewpaymentAddComponent],
  entryComponents:[NewpaymentAddComponent]
})
export class NewPaymentPageModule {}

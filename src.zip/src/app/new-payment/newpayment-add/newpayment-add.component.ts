import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-newpayment-add',
  templateUrl: './newpayment-add.component.html',
  styleUrls: ['./newpayment-add.component.scss'],
})
export class NewpaymentAddComponent implements OnInit {
  @ViewChild('f') form: NgForm;

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {}

  onCancelPayment(){
   this.modalCtrl.dismiss(null, 'cancel');
  }

  addPaymentMode() {
    console.log(this.form.value['PaymentmodeName']);
    if (!this.form.valid) {
      return;
    }
    this.modalCtrl.dismiss(
      {
        paymentDetail: {
          paymentName: this.form.value['PaymentmodeName'],
          paymentDesc: this.form.value['PaymentmodeDesc'],
        }
      },
      'confirm'
    );
  }
}

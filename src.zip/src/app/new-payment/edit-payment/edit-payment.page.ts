import { Component, OnInit, OnDestroy } from '@angular/core';
import { Payment } from '../payment.model';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../payment.service';
import { NavController, LoadingController, AlertController } from '@ionic/angular';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-edit-payment',
  templateUrl: './edit-payment.page.html',
  styleUrls: ['./edit-payment.page.scss'],
})
export class EditPaymentPage implements OnInit , OnDestroy {

  paymentId: any;
  product: Payment;
  private subscriptionObj: Subscription;
  form: FormGroup;
  isLoading = false;

  constructor(private route: ActivatedRoute,
              private paymentService: PaymentService,
              private navCtrl: NavController,
              private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private loginService: LoginService
    ) { }


    ngOnInit() {
      this.route.paramMap.subscribe(paramMap => {
        if (!paramMap.has('id')) {
         console.log('Not Found..');
         return;
        }
        this.isLoading = true;
        this.paymentId = paramMap.get('id');
        console.log('this.productId ' + this.paymentId);
        this.subscriptionObj = this.paymentService.getSinglePaymentDetail(this.paymentId)
        .subscribe(
          paymentObj => {
            this.form = new FormGroup({
              paymentName: new FormControl(paymentObj.paymentName , {
                updateOn: 'change',
                validators: [Validators.required]
              }),
              paymentDesc: new FormControl(paymentObj.paymentDesc, {
                updateOn: 'change',
                validators: [Validators.required]
              })
            });
            this.isLoading = false;
          },
          error => {
            this.alertCtrl
              .create({
                header: 'An error occurred!',
                message: 'Place could not be fetched. Please try again later.',
                buttons: [
                  {
                    text: 'Okay',
                    handler: () => {
                     this.router.navigate(['/dashboard']);
                    }
                  }
                ]
              })
              .then(alertEl => {
                alertEl.present();
              });
          }
        );
      });
    }

    get PaymentmodeName() {
      return this.form.get('paymentName');
    }
    get PaymentmodeDesc() {
      return this.form.get('paymentDesc');
    }

    updatePayment() {
      if (!this.form.valid) {
        return;
      }
      this.loadingCtrl
        .create({
          message: 'Updating Payment Details...'
        })
        .then(loadingEl => {
          loadingEl.present();
          this.paymentService.updatePayment(
              this.paymentId,
              this.form.value.paymentName,
              this.form.value.paymentDesc,
              this.loginService.login()
            )
            .subscribe(() => {
              loadingEl.dismiss();
              this.form.reset();
              this.router.navigate(['/new-payment']);
            });
        });
    }

    ngOnDestroy() {
      if (this.subscriptionObj) {
        this.subscriptionObj.unsubscribe();
      }
    }
}

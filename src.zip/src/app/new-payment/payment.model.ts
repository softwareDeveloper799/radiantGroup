

export class Payment {
    constructor(
      public id: string,
      public paymentName: string,
      public paymentDesc: string,
      public loginUserId: string
    ) {}
  }
import { Injectable } from '@angular/core';
import { Payment } from './payment.model';
import { BehaviorSubject, of } from 'rxjs';
import { take, tap, map, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { LoginService } from '../login/login.service';

interface PaymentInterface {
  paymentName: string;
  paymentDesc: string;
  loginUserId: string;
}

@Injectable({
  providedIn: 'root'
})

export class PaymentService {
      // tslint:disable-next-line: variable-name
      private _payMents = new BehaviorSubject<Payment[]>([
        // new Payment('0' , 'Cash'            , 'Payment Done by cash mode'),
        // new Payment('1' , 'Demand Draft'    , 'Payment Done by DD')
      ]);

      get getPaymentDetails() {
        return this._payMents.asObservable();
      }

      constructor(private http: HttpClient ,
                  private loginService: LoginService) { }

      fetchPayment(userId: string) {
        // tslint:disable-next-line: max-line-length
        return this.http.get<{[key: string]: Payment}>(`https://subscriptionmanagementservice.firebaseio.com/payment-details.json?orderBy="loginUserId"&equalTo=${userId}`)
        .pipe(map(resData => {
          const PaymentArray = [];
          for (const key in resData) {
             if ( resData.hasOwnProperty(key)) {
              PaymentArray.push(new Payment(
                 key,
                 resData[key].paymentName,
                 resData[key].paymentDesc,
                 resData[key].loginUserId,
                 ));
             }
           }
          return PaymentArray;
       // return [];
        }),
        tap(resArrayFromMap => {
          this._payMents.next(resArrayFromMap);
         })
        );
      }

      addNewPayment(PaymentName: string , PaymentDesc: string , userId: string) {
        const newPayment = new Payment(
        Math.random().toString(),
        PaymentName,
        PaymentDesc,
        userId
        );
        // console.log('newPayment : ' + JSON.stringify(newPayment));
        // return this.getPaymentDetails.pipe(
        // take(1),
        // tap(product => {
        // console.log(' this._places 1 : ');
        // this._payMents.next(product.concat(newPayment));
        // })
        // );
        let generatedId: string;
        console.log('newPayment : ' + JSON.stringify(newPayment));
        // tslint:disable-next-line: max-line-length
        return this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/payment-details.json', {...newPayment , id: null})
               .pipe(
                  switchMap(resData => {
                    generatedId = resData.name;
                    return this.getPaymentDetails;
                  }),
                  take(1),
                  tap(plan => {
                      console.log(' this._places 1 : ');
                      newPayment.id =  generatedId;
                      this._payMents.next(plan.concat(newPayment));
                   })
               );

      }

      getSinglePaymentDetail(id: string) {
        // return this.getPaymentDetails.pipe(
        // take(1),
        // map(plan => {
        //   return { ...plan.find(p => p.id === id) };
        // })
        // );

        return this.http.get<PaymentInterface>(`https://subscriptionmanagementservice.firebaseio.com/payment-details/${id}.json`
        ).pipe(
          // tslint:disable-next-line: no-shadowed-variable
          map(PaymentDataForOne => {
            return new Payment (
                id,
                PaymentDataForOne.paymentName,
                PaymentDataForOne.paymentDesc,
                PaymentDataForOne.loginUserId
              );
            })
          );

      }

      updatePayment(paymentId: string, PaymentName: string, paymentDesc: string, userId: string ) {
        //   let updatedPayment: Payment[];
        //   return this._payMents.pipe(
        //   take(1),
        //   switchMap(product => {
        //     if (!product || product.length <= 0) {
        //       // return this.fetchPlaces();
        //     } else {
        //       return of(product);
        //     }
        //   }),
        //   tap((products) => {
        //     const updatedPayMentIndex = products.findIndex(pl => pl.id === paymentId);
        //     updatedPayment = [...products];
        //     const oldPlace = updatedPayment[updatedPayMentIndex];
        //     updatedPayment[updatedPayMentIndex] = new Payment(
        //       oldPlace.id,
        //       PaymentName,
        //       paymentDesc,
        //     );
        //     this._payMents.next(updatedPayment);
        //   })
        // );

        let updatedPayment: Payment[];
        return this._payMents.pipe(
          take(1),
          switchMap(payment => {
            if ( !payment || payment.length <= 0) {
              return this.fetchPayment(userId);
            } else {
              return of(payment);
            }
          }),
          switchMap((payments) => {
            const updatedPaymentIndex = payments.findIndex(pl => pl.id === paymentId);
            updatedPayment = [...payments];
            const oldPayment = updatedPayment[updatedPaymentIndex];
            updatedPayment[updatedPaymentIndex] = new Payment(
              oldPayment.id,
              PaymentName,
              paymentDesc,
              userId
            );
            return this.http.put(`https://subscriptionmanagementservice.firebaseio.com/payment-details/${paymentId}.json`,
              {... updatedPayment[updatedPaymentIndex] , id: null}
              );
            }),
            tap((resData) => {
            this._payMents.next(updatedPayment);
          }));
      }


      onDeletePayment(paymentId: string) {
        return this.http.delete(`https://subscriptionmanagementservice.firebaseio.com/payment-details/${paymentId}.json`
        ).pipe(
          switchMap(() => {
          return this.getPaymentDetails;
        }),
          take(1),
          tap(products => {
            this._payMents.next(products.filter(b => b.id !== paymentId));
        }));
      }
}

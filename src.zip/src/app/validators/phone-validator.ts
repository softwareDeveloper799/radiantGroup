import { AbstractControl } from '@angular/forms';

// export function phoneNumberValidator( control: AbstractControl ): { [key: string]: any } | null {
//   alert(control.value);
//   const valid = /^d+$/.test(control.value);
//   alert('valid :: ' + valid);
//   return valid ? null : { invalidNumber: { valid: false, value: control.value } }
// }

export function phoneNumberValidator( control: AbstractControl ) {
    //console.log(control.value);
    //console.log(typeof(control.value));
   // console.log(this.form.get('mobileNumber').errors);
    if (isNaN(control.value) === true) {
        return { value: false , invalidNumber: false };
    }

    console.log(isNaN(control.value));
    return null;
}


import { Injectable } from '@angular/core';
import { Plan } from './newPlan.model';
import { BehaviorSubject, of } from 'rxjs';
import { take, tap, map, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

interface PlanInterface {
  planDesc: string;
  planName: string;
  planRate: string;
  loginUserId: string;
}

@Injectable({
  providedIn: 'root'
})

export class PlanService {
// tslint:disable-next-line: variable-name
  private _plans = new BehaviorSubject<Plan[]>([
    // new Plan('0' , 'Monthly'    , '200' , 'Per Month Payment'),
    // new Plan('1' , 'Quaterly'   , '250' , 'Pay on starting of every 3rd Month'),
    // new Plan('2' , 'HalfYearly' , '550' , 'Pay on every 6 month'),
    // new Plan('3' , 'Yearly'     , '1200' , 'pay for 1 year'),
    // new Plan('4' , 'PerDay'     , '50' , 'pay on every day'),
  ]);

get getPlansDetail() {
 return this._plans.asObservable();
}

constructor(private http: HttpClient) { }

fetchPlan(userId: string) {
  return this.http.get<{[key: string]: Plan}>(`https://subscriptionmanagementservice.firebaseio.com/plan-details.json?orderBy="loginUserId"&equalTo=${userId}`)
  .pipe(map(resData => {
    const PlanArray = [];
    for (const key in resData) {
       if ( resData.hasOwnProperty(key)) {
        PlanArray.push(new Plan(
           key,
           resData[key].planName ,
           resData[key].planRate ,
           resData[key].planDesc,
           resData[key].loginUserId,
           ));
       }
     }
    return PlanArray;
 // return [];
  }),
  tap(resArrayFromMap => {
    this._plans.next(resArrayFromMap);
   })
  );
}

addNewPlan(PlanName: string , PlanDesc: string , PlanRate: string, loginUserId: string) {
const newPlan = new Plan(
 Math.random().toString(),
 PlanName,
 PlanRate,
 PlanDesc,
 loginUserId
);
// console.log('newProduct : ' + JSON.stringify(newProduct));
// return this.getPlansDetail.pipe(
//  take(1),
//  tap(product => {
//    console.log(' this._places 1 : ');
//    this._plans.next(product.concat(newProduct));
//   })
// );
let generatedId: string;
console.log('newPlan : ' + JSON.stringify(newPlan));
// tslint:disable-next-line: max-line-length
return  this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/plan-details.json', {...newPlan , id: null})
       .pipe(
          switchMap(resData => {
            generatedId = resData.name;
            return this.getPlansDetail;
          }),
          take(1),
          tap(plan => {
              console.log(' this._places 1 : ');
              newPlan.id =  generatedId;
              this._plans.next(plan.concat(newPlan));
           })
       );
}

getSinglePlanDetail(id: string) {
//  return this.getPlansDetail.pipe(
//    take(1),
//    map(plan => {
//      return { ...plan.find(p => p.id === id) };
//    })
//  );
return this.http.get<PlanInterface>(`https://subscriptionmanagementservice.firebaseio.com/plan-details/${id}.json`
).pipe(
  // tslint:disable-next-line: no-shadowed-variable
  map(PlanDataForOne => {
    return new Plan (
        id,
        PlanDataForOne.planName,
        PlanDataForOne.planRate,
        PlanDataForOne.planDesc,
        PlanDataForOne.loginUserId
      );
    })
  );

}

updatePlan(planId: string, planName: string, PlanDesc: string, planRate: string , loginUserId: string) {
//  let updatedPlan: Plan[];
//  return this._plans.pipe(
//    take(1),
//    switchMap(product => {
//      if (!product || product.length <= 0) {
//       // return this.fetchPlaces();
//      } else {
//        return of(product);
//      }
//    }),
//    tap((products) => {
//      const updatedPlanIndex = products.findIndex(pl => pl.id === planId);
//      updatedPlan = [...products];
//      const oldPlace = updatedPlan[updatedPlanIndex];
//      updatedPlan[updatedPlanIndex] = new Plan(
//        oldPlace.id,
//        planName,
//        planRate,
//        PlanDesc
//      );
//      this._plans.next(updatedPlan);
//    })
//  );
// }

let updatedPlan: Plan[];
return this._plans.pipe(
   take(1),
   switchMap(plan => {
    if ( !plan || plan.length <= 0) {
      return this.fetchPlan(loginUserId);
    } else {
      return of(plan);
    }
  }),
  switchMap((plans) => {
    const updatedPlaceIndex = plans.findIndex(pl => pl.id === planId);
    updatedPlan = [...plans];
    const oldPlan = updatedPlan[updatedPlaceIndex];
    updatedPlan[updatedPlaceIndex] = new Plan(
      oldPlan.id,
      planName,
      planRate,
      PlanDesc,
      loginUserId
    );
    return this.http.put(`https://subscriptionmanagementservice.firebaseio.com/plan-details/${planId}.json`,
       {... updatedPlan[updatedPlaceIndex] , id: null}
      );
    }),
    tap((resData) => {
    this._plans.next(updatedPlan);
  }));

  }


  onDeletePlan(planId: string) {
    return this.http.delete(`https://subscriptionmanagementservice.firebaseio.com/plan-details/${planId}.json`
    ).pipe(
      switchMap(() => {
      return this.getPlansDetail;
    }),
      take(1),
      tap(products => {
        this._plans.next(products.filter(b => b.id !== planId));
    }));
  }

}

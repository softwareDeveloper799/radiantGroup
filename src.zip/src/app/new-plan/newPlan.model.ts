export class Plan {
    constructor(
      public id: string,
      public planName: string,
      public planRate: string,
      public planDesc: string,
      public loginUserId: string
    ) {}
  }
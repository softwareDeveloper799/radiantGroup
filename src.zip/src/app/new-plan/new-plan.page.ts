import { Component, OnInit } from '@angular/core';
import { NewplanAddComponent } from './newplan-add/newplan-add.component';
import { ModalController, LoadingController } from '@ionic/angular';
import { PlanService } from './plan.service';
import { Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-new-plan',
  templateUrl: './new-plan.page.html',
  styleUrls: ['./new-plan.page.scss'],
})
export class NewPlanPage implements OnInit {
  
  isLoading = false;
  planArray: any;
  private subscriptionObj: Subscription;
  constructor(private modalCtrl: ModalController , private planService: PlanService,
              private loadingCtrl: LoadingController,
              private loginService: LoginService) { }

  ngOnInit() {
        this.subscriptionObj = this.planService.getPlansDetail
        .subscribe(planDetail => {
          console.log('planDetail ' + JSON.stringify(planDetail));
          this.planArray = planDetail;
      });
  }

  ionViewWillEnter() {
    this.isLoading = true;
    this.planService.fetchPlan(this.loginService.login()).subscribe(() => {
      this.isLoading = false;
    });
  }

  onPlanAdd() {
    // console.log(`Enter Update Select`);
    // this.modalCtrl
    //    .create({
    //      component: NewplanAddComponent,
    //      componentProps: { value : 123}
    //    })
    //    .then(modalEl => {
    //      modalEl.present();
    //      return modalEl.onDidDismiss();
    //    })
    //    .then(resultData => {
    //      console.log(`Enter Here New Plan Add` + JSON.stringify(resultData));
    //     //  this.planArray.push(resultData.data.planDetail);
    //      this.planService.addNewPlan(resultData.data.planDetail.planName ,
    //       resultData.data.planDetail.planDesc ,
    //       resultData.data.planDetail.planRate ,
    //       ).subscribe(() => {

    //       });
    //    });

       this.modalCtrl
       .create({
         component: NewplanAddComponent,
         componentProps: { value : 123}
       })
       .then(modalEl => {
         modalEl.present();
         return modalEl.onDidDismiss();
       })
       .then(resultData => {
         console.log(`Enter Here ` + JSON.stringify(resultData));
         if(resultData.data != null) {
           this.loadingCtrl
          .create({
            message: 'Adding plan...'
          })
          .then(loadingEl => {
            loadingEl.present();
            console.log(`Enter Here New Plan Add` + JSON.stringify(resultData));
            this.planService.addNewPlan(
              resultData.data.planDetail.planName ,
              resultData.data.planDetail.planDesc ,
              resultData.data.planDetail.planRate ,
              this.loginService.login()
              ).subscribe(() => {
                loadingEl.dismiss();
              });
           });
          }
       });


     }

    onPlanedit(plan , slidingItem) {
      console.log('onPlanedit :: ' + JSON.stringify(plan));
      slidingItem.close();
    }

    onPlandelete(plan , slidingItem) {
     console.log('onPlandelete :: ' + JSON.stringify(plan));
     slidingItem.close();
    }
}

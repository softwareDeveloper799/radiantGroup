import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-newplan-add',
  templateUrl: './newplan-add.component.html',
  styleUrls: ['./newplan-add.component.scss'],
})
export class NewplanAddComponent implements OnInit {
  @ViewChild('f') form: NgForm;
  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {}

  onCancelPlan(){
    console.log('Call From Model Ts');
    this.modalCtrl.dismiss(null , 'cancel');
  }
  
  addPlan(){
    if (!this.form.valid) {
      return;
    }
    this.modalCtrl.dismiss(
      {
        planDetail: {
          planName: this.form.value['planName'],
          planDesc: this.form.value['planDesc'],
          planRate: this.form.value['planRate'],
        }
      },
      'confirm'
    );
  }
}

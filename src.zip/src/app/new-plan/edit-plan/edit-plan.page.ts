import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, LoadingController, AlertController } from '@ionic/angular';
import { PlanService } from '../plan.service';
import { Subscription } from 'rxjs';
import { Plan } from '../newPlan.model';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-edit-plan',
  templateUrl: './edit-plan.page.html',
  styleUrls: ['./edit-plan.page.scss'],
})
export class EditPlanPage implements OnInit , OnDestroy{

  planId: any;
  product: Plan;
  private subscriptionObj: Subscription;
  form: FormGroup;
  isLoading = false;

  constructor(private route: ActivatedRoute,
              private planService: PlanService,
              private navCtrl: NavController,
              private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private loginService: LoginService
    ) { }


    ngOnInit() {
      this.route.paramMap.subscribe(paramMap => {
        if (!paramMap.has('id')) {
         console.log('Not Found..');
         return;
        }
        this.isLoading = true;
        this.planId = paramMap.get('id');
        console.log('this.productId ' + this.planId);
        this.subscriptionObj = this.planService.getSinglePlanDetail(this.planId)
        .subscribe(
          plan => {
            this.form = new FormGroup({
              planName: new FormControl(plan.planName , {
                updateOn: 'change',
                validators: [Validators.required]
              }),
              planDesc: new FormControl(plan.planDesc, {
                updateOn: 'change',
                validators: [Validators.required]
              }),
  
              planRate: new FormControl(plan.planRate, {
                updateOn: 'change',
                validators: [Validators.required]
              })
            });
            this.isLoading = false;
          },
          error => {
            this.alertCtrl
              .create({
                header: 'An error occurred!',
                message: 'Place could not be fetched. Please try again later.',
                buttons: [
                  {
                    text: 'Okay',
                    handler: () => {
                     this.router.navigate(['/dashboard']);
                    }
                  }
                ]
              })
              .then(alertEl => {
                alertEl.present();
              });
          }
        );
      });
    }

    get planName() {
      return this.form.get('planName');
    }
    get planDesc() {
      return this.form.get('planDesc');
    }
    get planRate() {
      return this.form.get('planRate');
    }

    updatePlan() {
      if (!this.form.valid) {
        return;
      }
      this.loadingCtrl
        .create({
          message: 'Updating paln Details...'
        })
        .then(loadingEl => {
          loadingEl.present();
          this.planService.updatePlan(
              this.planId,
              this.form.value.planName,
              this.form.value.planDesc,
              this.form.value.planRate,
              this.loginService.login()
            )
            .subscribe(() => {
              loadingEl.dismiss();
              this.form.reset();
              this.router.navigate(['/new-plan']);
            });
        });
    }

    ngOnDestroy() {
      if (this.subscriptionObj) {
        this.subscriptionObj.unsubscribe();
      }
    }
}

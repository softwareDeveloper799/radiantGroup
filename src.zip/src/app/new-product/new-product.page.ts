import { Component, OnInit, OnDestroy } from '@angular/core';
import { NewproductAddComponent } from './newproduct-add/newproduct-add.component';
import { ModalController, LoadingController } from '@ionic/angular';
import { ProdcutServiceService } from '../prodcut-service.service';
import { Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';


@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.page.html',
  styleUrls: ['./new-product.page.scss'],
})
export class NewProductPage implements OnInit , OnDestroy {
   dummyList: any;
   searchTerm: any;
   isLoading = false;
   private subscriptionObj: Subscription;


   constructor(  private modalCtrl: ModalController,
                 private productService: ProdcutServiceService,
                 private loadingCtrl: LoadingController,
                 private loginService: LoginService) { }

  ngOnInit() {
    this.subscriptionObj = this.productService.getProductsDetail
      .subscribe(prDetail => {
          console.log('prDetail ' + JSON.stringify(prDetail));
          this.dummyList = prDetail;
      });
  }

  ionViewWillEnter() {
    this.isLoading = true;
    this.productService.fetchProducts(this.loginService.login()).subscribe(() => {
      this.isLoading = false;
    });
  }

  setFilteredLocations() {
    console.log('searchTerm :: ' + this.searchTerm);
    return this.dummyList.filter((location: { title: { toLowerCase: () => { indexOf: (arg0: any) => number; }; }; }) => {
      return location.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
    });
  }

  onAddProduct() {
    console.log(`Enter Update Select`);
    this.modalCtrl
       .create({
         component: NewproductAddComponent,
         componentProps: { value : 123}
       })
       .then(modalEl => {
         modalEl.present();
         return modalEl.onDidDismiss();
       })
       .then(resultData => {
         console.log(`Enter Here ` + JSON.stringify(resultData));
         if (resultData.data != null) {
           this.loadingCtrl
          .create({
            message: 'Adding product...'
          })
          .then(loadingEl => {
            loadingEl.present();
            this.productService.addProduct(resultData.data.productDetail.name ,
              resultData.data.productDetail.productNo,
              // tslint:disable-next-line: max-line-length
              resultData.data.productDetail.shortDesc , 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_S9DUg_S9CHf-DxgcNbxYzZmibzud95wxTQslnreREOxA1ch1', this.loginService.login()).subscribe(() => {
                loadingEl.dismiss();
            });
           });
          }
       });
     }

    onedit(product: any , slidingItem) {
      console.log('OnEdit :: ' + JSON.stringify(product));
      slidingItem.close();
    }

    ondelete(productId: string ,  slidingItem) {
     console.log('OnDelete :: ' + JSON.stringify(productId));
     slidingItem.close();
     this.loadingCtrl
          .create({
            message: 'Deleting product...'
          })
          .then(loadingEl => {
            loadingEl.present();
            this.productService.onDeleteProduct(productId).subscribe(() => {
              loadingEl.dismiss();
            });
           });
    }

    ngOnDestroy() {
      if (this.subscriptionObj ) {
          this.subscriptionObj.unsubscribe();
      }
    }

  }

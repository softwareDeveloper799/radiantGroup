import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { NewProductPage } from './new-product.page';
import { NewproductAddComponent } from './newproduct-add/newproduct-add.component';

const routes: Routes = [
  {
    path: '',
    component: NewProductPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [NewProductPage,NewproductAddComponent],
  entryComponents:[NewproductAddComponent]
})
export class NewProductPageModule {}

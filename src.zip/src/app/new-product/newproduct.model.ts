export class Product {
    constructor(
      public id: string,
      public name: string,
      public prdocutNo: string,
      public shortdesc: string,
      public imgUrl: string,
      public loginUserId: string
    ) {}
  }
  
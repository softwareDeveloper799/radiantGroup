import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProdcutServiceService } from 'src/app/prodcut-service.service';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NavController, LoadingController, AlertController } from '@ionic/angular';
import { Product } from '../newproduct.model';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.page.html',
  styleUrls: ['./edit-product.page.scss'],
})
export class EditProductPage implements OnInit , OnDestroy {

  productId: any;
  product: Product;
  private subscriptionObj: Subscription;
  form: FormGroup;
  isLoading = false;

  constructor(private route: ActivatedRoute,
              private productService: ProdcutServiceService,
              private navCtrl: NavController,
              private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private loginService: LoginService
    ) { }

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('id')) {
       console.log('Not Found..');
       return;
      }
      this.isLoading = true;
      this.productId = paramMap.get('id');
      console.log('this.productId ' + this.productId);
      this.subscriptionObj = this.productService.getDetailProduct(this.productId)
      .subscribe(
        place => {
          this.form = new FormGroup({
            title: new FormControl(place.name, {
              updateOn: 'change',
              validators: [Validators.required]
            }),
            productNo: new FormControl(place.prdocutNo, {
              updateOn: 'change',
              validators: [Validators.required]
            }),

            description: new FormControl(place.shortdesc, {
              updateOn: 'change',
              validators: [Validators.required]
            })
          });
          this.isLoading = false;
        },
        error => {
          this.alertCtrl
            .create({
              header: 'An error occurred!',
              message: 'Product could not be fetched. Please try again later.',
              buttons: [
                {
                  text: 'Okay',
                  handler: () => {
                   this.router.navigate(['/dashboard']);
                  }
                }
              ]
            })
            .then(alertEl => {
              alertEl.present();
            });
        }
      );
    });
  }

 get title() {
   return this.form.get('title');
 }
 get productNo() {
  return this.form.get('productNo');
 }
 get description() {
  return this.form.get('description');
 }

  updateProduct() {
    if (!this.form.valid) {
      return;
    }
    this.loadingCtrl
      .create({
        message: 'Updating product...'
      })
      .then(loadingEl => {
        loadingEl.present();
        this.productService.updateProduct(
            this.productId,
            this.form.value.title,
            this.form.value.productNo,
            this.form.value.description,
            this.loginService.login()
          )
          .subscribe(() => {
            loadingEl.dismiss();
            this.form.reset();
            this.router.navigate(['/new-product']);
          });
      });
  }

  ngOnDestroy() {
    if (this.subscriptionObj) {
      this.subscriptionObj.unsubscribe();
    }
  }
}

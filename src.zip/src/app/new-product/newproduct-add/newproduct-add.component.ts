import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-newproduct-add',
  templateUrl: './newproduct-add.component.html',
  styleUrls: ['./newproduct-add.component.scss'],
})
export class NewproductAddComponent implements OnInit {
  @ViewChild('f') form: NgForm;
  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {}

  onCancel(){
    console.log('Call From Model Ts');
    this.modalCtrl.dismiss(null , 'cancel');
  }
  
  addProduct(){
    if (!this.form.valid) {
      return;
    }

    this.modalCtrl.dismiss(
      {
        productDetail: {
          name: this.form.value['productName'],
          productNo: this.form.value['productNumber'],
          shortDesc: this.form.value['productDesc'],
        }
      },
      'confirm'
    );
  }

}

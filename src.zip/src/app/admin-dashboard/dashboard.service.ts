import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Dashboard } from './dashboard.model';
import { switchMap, map, tap, take } from 'rxjs/operators';
import { User } from '../new-user/user.model';
import { LoginService } from '../login/login.service';

interface DashBoardBarChartOne {
     loginUserId: string;
     barChartMonth: [];
}

interface DashBoardBarChartSecond {
  loginUserId: string;
  barChartMonth: [];
}

interface DashBoardBarChartThird {
  loginUserId: string;
  barChartMonth: [];
}


@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  month: any;
  constructor(private http: HttpClient , private loginService: LoginService) { }

  // tslint:disable-next-line: variable-name
  private dashboardBehaviorObj_ONE = new BehaviorSubject<Dashboard[]>([]);
  // tslint:disable-next-line: variable-name
  private dashboardBehaviorObj_SECOND = new BehaviorSubject<Dashboard[]>([]);
  // tslint:disable-next-line: variable-name
  private dashboardBehaviorObj_THIRD = new BehaviorSubject<Dashboard[]>([]);

  get getDashboardDetail_ONE() {
    return this.dashboardBehaviorObj_ONE.asObservable();
  }

  get getDashboardDetail_SECOND() {
    return this.dashboardBehaviorObj_SECOND.asObservable();
  }

  get getDashboardDetail_THIRD() {
    return this.dashboardBehaviorObj_THIRD.asObservable();
  }

  fetchDashBoardData_one(loginUsreId) {
    const ProductArray = [];
          // tslint:disable-next-line: max-line-length
    return this.http.get<DashBoardBarChartOne>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_ONE.json?orderBy="loginUserId"&equalTo=${loginUsreId}`)
          .pipe(
            take(1),
            tap(chartData =>{
              console.log(chartData);
              for (const key in chartData) {
                if ( chartData.hasOwnProperty(key)) {
                  console.log(chartData[key].barChartMonth);
                  this.dashboardBehaviorObj_ONE.next(chartData[key].barChartMonth);
                }
              }
            }));
   }

   fetchDashBoardData_second(loginUsreId) {
    const ProductArray = [];
          // tslint:disable-next-line: max-line-length
    return this.http.get<DashBoardBarChartSecond>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_SECOND.json?orderBy="loginUserId"&equalTo=${loginUsreId}`)
          .pipe(
            take(1),
            tap(chartData =>{
              console.log(chartData);
              for (const key in chartData) {
                if ( chartData.hasOwnProperty(key)) {
                  console.log(chartData[key].barChartMonth);
                  this.dashboardBehaviorObj_SECOND.next(chartData[key].barChartMonth);
                }
              }
            }));
   }

   fetchDashBoardData_third(loginUsreId) {
    const ProductArray = [];
          // tslint:disable-next-line: max-line-length
    return this.http.get<DashBoardBarChartThird>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_THIRD.json?orderBy="loginUserId"&equalTo=${loginUsreId}`)
          .pipe(
            take(1),
            tap(chartData => {
              console.log(chartData);
              for (const key in chartData) {
                if ( chartData.hasOwnProperty(key)) {
                  console.log(chartData[key].barChartMonth);
                  this.dashboardBehaviorObj_THIRD.next(chartData[key].barChartMonth);
                }
              }
            }));
   }


  addDashBoardBarChartData_ONE() {

  const userId =  this.loginService.login();
  const dateObj = new Date();
  this.month =  dateObj.getMonth();
  const monthArray = new Array();
  let barChartMonthObjKey = null;
  let dummyArray = [];

    // tslint:disable-next-line: max-line-length
  this.http.get<{[key: string]: DashBoardBarChartOne}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_ONE.json?orderBy="loginUserId"&equalTo=${userId}`).subscribe((res) => {
      console.log(res);
      if (Object.getOwnPropertyNames(res).length !== 0) {
        console.log(` Enter IF`);
        for (const key in res) {
        if (res.hasOwnProperty(key)) {
            console.log(key + ' -> ' + res[key]);
            barChartMonthObjKey = res[key];
           // tslint:disable-next-line: max-line-length
            this.http.get<DashBoardBarChartOne>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_ONE/${key}.json`).subscribe((singleRecord) => {
           console.log(singleRecord);
           dummyArray =  singleRecord.barChartMonth;

           for ( let i = 0; i < 12; i++) {
            console.log( `${i} Key ${dummyArray[i]} `);
            if ( i ===  this.month) {
              dummyArray[i] = dummyArray[i] + 1;
            }
          }
           const json = { loginUserId: userId , barChartMonth: dummyArray };
           // tslint:disable-next-line: max-line-length
           this.http.put<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_ONE/${key}.json`, { loginUserId: userId , barChartMonth: dummyArray }).subscribe((resDataUpdate) => {
              console.log(resDataUpdate);
           });
        });
            break;
        //}
         } else {

        }
      }
     } else {
      console.log(` Enter ELSE`);
      const monthFinal = this.month;

      for ( let i = 0; i < 12; i++) {
          console.log( `${i} Key ${monthFinal} `);
          if ( i === monthFinal) {
            monthArray[i] = 1;
          } else {
            monthArray[i] = 0;
          }
        }

      const json = { loginUserId: userId , barChartMonth: monthArray };
      console.log(monthArray);
        // tslint:disable-next-line: max-line-length
      this.http.post<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_ONE.json`, { loginUserId: userId , barChartMonth: monthArray }).subscribe((resData) => {
           console.log(resData);
        });
    }
   });
  }



  addDashBoardBarChartData_SECOND() {

    const userId =  this.loginService.login();
    const dateObj = new Date();
    this.month =  dateObj.getMonth();
    const monthArray = new Array();
    let barChartMonthObjKey = null;
    let dummyArray = [];
      // tslint:disable-next-line: max-line-length
    this.http.get<{[key: string]: DashBoardBarChartSecond}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_SECOND.json?orderBy="loginUserId"&equalTo=${userId}`).subscribe((res) => {
        console.log(res);
        if (Object.getOwnPropertyNames(res).length !== 0) {
          console.log(` Enter IF`);
          for (const key in res) {
          if (res.hasOwnProperty(key)) {
              console.log(key + ' -> ' + res[key]);
              barChartMonthObjKey = res[key];
             // tslint:disable-next-line: max-line-length
              this.http.get<DashBoardBarChartSecond>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_SECOND/${key}.json`).subscribe((singleRecord) => {
             console.log(singleRecord);
             dummyArray =  singleRecord.barChartMonth;
             for ( let i = 0; i < 12; i++) {
              console.log( `${i} Key ${dummyArray[i]} `);
              if ( i ===  this.month) {
                dummyArray[i] = dummyArray[i] + 1;
              }
            }
             const json = { loginUserId: userId , barChartMonth: dummyArray };
             // tslint:disable-next-line: max-line-length
             this.http.put<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_SECOND/${key}.json`, { loginUserId: userId , barChartMonth: dummyArray }).subscribe((resDataUpdate) => {
                console.log(resDataUpdate);
             });
          });
              break;
          //}
           } else {
          }
        }
       } else {
        console.log(` Enter ELSE`);
        const monthFinal = this.month;
        for ( let i = 0; i < 12; i++) {
            console.log( `${i} Key ${monthFinal} `);
            if ( i === monthFinal) {
              monthArray[i] = 1;
            } else {
              monthArray[i] = 0;
            }
          }
        const json = { loginUserId: userId , barChartMonth: monthArray };
        console.log(monthArray);
          // tslint:disable-next-line: max-line-length
        this.http.post<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_SECOND.json`, { loginUserId: userId , barChartMonth: monthArray }).subscribe((resData) => {
             console.log(resData);
          });
      }
     });
    }


    addDashBoardBarChartData_THIRD() {

      const userId =  this.loginService.login();
      const dateObj = new Date();
      this.month =  dateObj.getMonth();
      const monthArray = new Array();
      let barChartMonthObjKey = null;
      let dummyArray = [];
        // tslint:disable-next-line: max-line-length
      this.http.get<{[key: string]: DashBoardBarChartThird}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_THIRD.json?orderBy="loginUserId"&equalTo=${userId}`).subscribe((res) => {
          console.log(res);
          if (Object.getOwnPropertyNames(res).length !== 0) {
            console.log(` Enter IF`);
            for (const key in res) {
            if (res.hasOwnProperty(key)) {
                console.log(key + ' -> ' + res[key]);
                barChartMonthObjKey = res[key];
               // tslint:disable-next-line: max-line-length
                this.http.get<DashBoardBarChartThird>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_THIRD/${key}.json`).subscribe((singleRecord) => {
               console.log(singleRecord);
               dummyArray =  singleRecord.barChartMonth;
               for ( let i = 0; i < 12; i++) {
                console.log( `${i} Key ${dummyArray[i]} `);
                if ( i ===  this.month) {
                  dummyArray[i] = dummyArray[i] + 1;
                }
              }
               const json = { loginUserId: userId , barChartMonth: dummyArray };
               // tslint:disable-next-line: max-line-length
               this.http.put<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_THIRD/${key}.json`, { loginUserId: userId , barChartMonth: dummyArray }).subscribe((resDataUpdate) => {
                  console.log(resDataUpdate);
               });
            });
                break;
            //}
             } else {
            }
          }
         } else {
          console.log(` Enter ELSE`);
          const monthFinal = this.month;
          for ( let i = 0; i < 12; i++) {
              console.log( `${i} Key ${monthFinal} `);
              if ( i === monthFinal) {
                monthArray[i] = 1;
              } else {
                monthArray[i] = 0;
              }
            }
          const json = { loginUserId: userId , barChartMonth: monthArray };
          console.log(monthArray);
            // tslint:disable-next-line: max-line-length
          this.http.post<{name: string}>(`https://subscriptionmanagementservice.firebaseio.com/userBarChart_THIRD.json`, { loginUserId: userId , barChartMonth: monthArray }).subscribe((resData) => {
               console.log(resData);
            });
        }
       });
      }
}

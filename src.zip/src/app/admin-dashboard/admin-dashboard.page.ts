import { Component, OnInit, ViewChild } from '@angular/core';
import { Chart } from 'chart.js';
import { DashboardService } from './dashboard.service';
import { Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.page.html',
  styleUrls: ['./admin-dashboard.page.scss'],
})
export class AdminDashboardPage implements OnInit {
  @ViewChild('barCanvas') barCanvas;
  @ViewChild('doughnutCanvas') doughnutCanvas;
  @ViewChild('lineCanvas') lineCanvas;

  
  @ViewChild('userName') userName;
 
  userFirstName:any;
  barChart: any;
  doughnutChart: any;
  lineChart: any;
  private subscriptionObj: Subscription;

  barChartDataOne: any;
  barChartDataSecond: any;
  barChartDataThird: any;
  isLoading: boolean;

  constructor(private dashboardService: DashboardService,
              private loginService: LoginService,
              private loadingCtrl: LoadingController) { }

  ngOnInit() {

    this.subscriptionObj = this.dashboardService.getDashboardDetail_ONE.subscribe(barChartDataONE => {
      console.log('barChartDataONE ' + JSON.stringify(barChartDataONE));
      this.barChartDataOne = barChartDataONE;
      console.log(this.barChartDataOne );
      this.barChartMethod();
    });

    this.subscriptionObj = this.dashboardService.getDashboardDetail_SECOND.subscribe(barChartDataSECOND => {
        console.log('barChartDataSECOND ' + JSON.stringify(barChartDataSECOND));
        this.barChartDataSecond = barChartDataSECOND;
        console.log(this.barChartDataSecond );
        this.doughnutChartMethod();
      });

    this.subscriptionObj = this.dashboardService.getDashboardDetail_THIRD.subscribe(barChartDataTHIRD => {
          console.log('barChartDataTHIRD ' + JSON.stringify(barChartDataTHIRD));
          this.barChartDataThird = barChartDataTHIRD;
          console.log(this.barChartDataThird );
          this.lineChartMethod();
    });
  }

  ionViewWillEnter() {
    this.loadingCtrl
          .create({
            message: 'Please wait...'
          })
          .then(loadingEl => {
            loadingEl.present();
            this.dashboardService.fetchDashBoardData_one(this.loginService.login()).subscribe(() => {
              this.dashboardService.fetchDashBoardData_second(this.loginService.login()).subscribe(() => {
                this.dashboardService.fetchDashBoardData_third(this.loginService.login()).subscribe(() => {
                  loadingEl.dismiss();
                   });
                });
            });
          });


    //this.dashboardService.addDashBoardBarChartData_THIRD();
  }

  barChartMethod() {
    this.barChart = new Chart(this.barCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June' , 'July', 'August' , 
        'September', 'October' , 'November' , 'December'],
        datasets: [{
          label: 'Student Registration By Month',
          data:  this.barChartDataOne, //[20, 50, 30, 15, 20, 34 , 43 , 43 ,12 ,42 , 43 ,23],
          backgroundColor: [
            'rgba(255, 99, 132)',
            'rgba(54, 162, 235)',
            'rgba(255, 206, 86)',
            'rgba(75, 192, 192)',
            'rgba(153, 102, 255)',
            'rgba(255, 159, 64)',
            'rgba(78, 96, 252)',
            'rgba(181, 87, 172)',
            'rgba(83, 212, 108)',
            'rgba(150, 140, 57)',
            'rgba(37, 219, 195)',
            'rgba(224, 34, 72)'
          ],
          borderColor: [
            'rgba(255,99,132,1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }

  doughnutChartMethod() {
    this.doughnutChart = new Chart(this.doughnutCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June' , 'July', 'August' , 
        'September', 'October' , 'November' , 'December'],
        datasets: [{
          label: 'Fees Deposite By Month',
          data:  this.barChartDataSecond, //[20, 50, 30, 15, 20, 34 , 43 , 43 ,12 ,42 , 43 ,23],
          backgroundColor: [
            'rgba(54, 162, 235)',
            'rgba(255, 99, 132)',
            'rgba(255, 206, 86)',
            'rgba(75, 192, 192)',
            'rgba(153, 102, 255)',
            'rgba(255, 159, 64)',
            'rgba(78, 96, 252)',
            'rgba(181, 87, 172)',
            'rgba(83, 212, 108)',
            'rgba(150, 140, 57)',
            'rgba(37, 219, 195)',
            'rgba(224, 34, 72)'
          ],
          borderColor: [
            'rgba(54, 162, 235, 1)',
            'rgba(255,99,132,1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
    // this.doughnutChart = new Chart(this.doughnutCanvas.nativeElement, {
    //   type: 'doughnut',
    //   data: {
    //     labels: ['January', 'February', 'March', 'April', 'May', 'June' , 'July', 'August' , 
    //     'September', 'October' , 'November' , 'December'],
    //     datasets: [{
    //       label: 'Fees Deposite Per Month',
    //       data: this.barChartDataSecond , //[50, 29, 15, 10, 7],
    //       backgroundColor: [
    //         'rgba(255, 99, 132)',
    //         'rgba(54, 162, 235)',
    //         'rgba(255, 206, 86)',
    //         'rgba(75, 192, 192)',
    //         'rgba(153, 102, 255)',
    //         'rgba(255, 159, 64)',
    //         'rgba(78, 96, 252)',
    //         'rgba(181, 87, 172)',
    //         'rgba(83, 212, 108)',
    //         'rgba(150, 140, 57)',
    //         'rgba(37, 219, 195)',
    //         'rgba(224, 34, 72)'
    //       ],
    //       hoverBackgroundColor: [
    //         '#FFCE56',
    //         '#FF6384',
    //         '#36A2EB',
    //         '#FFCE56',
    //         '#FF6384'
    //       ]
    //     }]
    //   }
    // });
  }

  lineChartMethod() {
    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'November', 'December'],
        datasets: [
          {
            label: 'Due Fees By Month',
            fill: false,
            lineTension: 0.1,
            backgroundColor: 'rgba(75,192,192,0.4)',
            borderColor: 'rgba(75,192,192,1)',
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: 'rgba(75,192,192,1)',
            pointBackgroundColor: '#fff',
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: 'rgba(75,192,192,1)',
            pointHoverBorderColor: 'rgba(220,220,220,1)',
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
            data:  this.barChartDataThird, // [65, 59, 80, 81, 56, 55, 40, 10, 5, 50, 10, 15],
            spanGaps: false,
          }
        ]
      }
    });
  }

 //}
//}
openMenu() {
  this.userName = this.loginService.firstName();
 }

}

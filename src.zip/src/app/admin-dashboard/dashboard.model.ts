export class Dashboard {
    constructor(
        public id: string,
        public dashBoard: [],
        public loginUserId: string
        ) {}
}


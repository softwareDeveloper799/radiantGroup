import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, of, Observable } from 'rxjs';
import { take, map, tap, delay, switchMap } from 'rxjs/operators';
import { RegisterUser } from './registration/registration.model';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private http: HttpClient) { }

  private registerUserBehaviorObj = new BehaviorSubject<RegisterUser[]>([]);

  get getRegisterUserDetail() {
    return this.registerUserBehaviorObj.asObservable();
  }

  registerUserService(registerUserObj: object) {
    console.log(registerUserObj);
    let registerId = null;
     // tslint:disable-next-line: max-line-length
    return this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/registration-details.json', {...registerUserObj})
    .pipe(
       switchMap(resData => {
          registerId = resData.name;
          return this.getRegisterUserDetail;
       }));
    }
}

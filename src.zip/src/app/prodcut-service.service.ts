import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, of, Observable } from 'rxjs';
import { take, map, tap, delay, switchMap } from 'rxjs/operators';
import {Product} from '../app/new-product/newproduct.model';

interface ProductData {
  name: string;
  imgUrl: string;
  prdocutNo: string;
  shortdesc: string;
  loginUserId: string;
}

@Injectable({
  providedIn: 'root'
})

export class ProdcutServiceService {

    // tslint:disable-next-line: max-line-length
    // new Product('0' , 'The Lion king tale' ,'B-1021', 'A story of jungke king' , 'https://images.penguinrandomhouse.com/cover/9780736439701'),
    // tslint:disable-next-line: max-line-length
    // new Product('1' , 'Two states'  , 'S-3024' ,'A love story from north and south' , 'https://upload.wikimedia.org/wikipedia/en/3/3a/2_States_-_The_Story_Of_My_Marriage.jpg' )

  private _places = new BehaviorSubject<Product[]>([
     ]);

 get getProductsDetail() {
    return this._places.asObservable();
  }

 constructor(private http: HttpClient) { }

 fetchProducts(userId: string) {
   return this.http.get<{[key: string]: ProductData}>(`https://subscriptionmanagementservice.firebaseio.com/product-details.json?orderBy="loginUserId"&equalTo=${userId}`)
   .pipe(map(resData => {
     const ProductArray = [];
     for (const key in resData) {
        if ( resData.hasOwnProperty(key)) {
          ProductArray.push(
            new Product(
              key,
              resData[key].name ,
              resData[key].prdocutNo ,
              resData[key].shortdesc ,
              resData[key].imgUrl,
              resData[key].loginUserId,
            ));
        }
      }
     return ProductArray;
  // return [];
   }),
   tap(resArrayFromMap => {
     this._places.next(resArrayFromMap);
    })
   );
 }

 addProduct(name: string , prdocutNo: string , shortDesc: string , imgUrl: string , loginUserId: string) {
   const newProduct = new Product(
    Math.random().toString(),
    name,
    prdocutNo,
    shortDesc,
    imgUrl,
    loginUserId
   );
   let generatedId: string;
   console.log('newProduct : ' + JSON.stringify(newProduct));
   // tslint:disable-next-line: max-line-length
   return  this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/product-details.json', {...newProduct , id: null})
          .pipe(
             switchMap(resData => {
               generatedId = resData.name;
               return this.getProductsDetail;
             }),
             take(1),
             tap(product => {
                 console.log(' this._places 1 : ');
                 newProduct.id =  generatedId;
                 this._places.next(product.concat(newProduct));
              })
          );
          //  return this.getProductsDetail.pipe(
          //   take(1),
          //   tap(product => {
          //     console.log(' this._places 1 : ');
          //     this._places.next(product.concat(newProduct));
          //    })
          //  );
  }

  getDetailProduct(id: string) {
    // return this.getProductsDetail.pipe(
    //   take(1),
    //   map(product => {
    //     return { ...product.find(p => p.id === id) };
    //   })
    // );
    return this.http.get<ProductData>(`https://subscriptionmanagementservice.firebaseio.com/product-details/${id}.json`
    ).pipe(
      // tslint:disable-next-line: no-shadowed-variable
      map(ProductDataForOne => {
        console.log(ProductDataForOne)
        return new Product (
            id,
            ProductDataForOne.name,
            ProductDataForOne.prdocutNo,
            ProductDataForOne.shortdesc,
            ProductDataForOne.imgUrl,
            ProductDataForOne.loginUserId
          );
        })
      );
  }

  updateProduct(productId: string, name: string, productNo: string, shortdescription: string , loginUserId: string) {
   /* let updatedPrpduct: Product[];
    return this._places.pipe(
      take(1),
      switchMap(product => {
        if (!product || product.length <= 0) {
         // return this.fetchPlaces();
        } else {
          return of(product);
        }
      }),
      // switchMap(places => {
      //   const updatedPlaceIndex = places.findIndex(pl => pl.id === productId);
      //   updatedPrpduct = [...places];
      //   const oldPlace = updatedPrpduct[updatedPlaceIndex];
      //   updatedPrpduct[updatedPlaceIndex] = new Product(
      //     oldPlace.id,
      //     name,
      //     shortdescription,
      //     oldPlace.imgUrl,
      //   );
      //   return { ...updatedPrpduct[updatedPlaceIndex], id: null };
        // return this.http.put(
        //   `https://ionic-angular-course.firebaseio.com/offered-places/${productId}.json`,
        //   { ...updatedPrpduct[updatedPlaceIndex], id: null }
        // );
      // }),
      tap((products) => {
        const updatedPlaceIndex = products.findIndex(pl => pl.id === productId);
        updatedPrpduct = [...products];
        const oldPlace = updatedPrpduct[updatedPlaceIndex];
        updatedPrpduct[updatedPlaceIndex] = new Product(
          oldPlace.id,
          name,
          productNo,
          shortdescription,
          oldPlace.imgUrl,
        );
        this._places.next(updatedPrpduct);
      })
    );*/
    let updatedPrpduct: Product[];
    return this._places.pipe(
       take(1),
       switchMap(products => {
        if ( !products || products.length <= 0) {
          return this.fetchProducts(loginUserId);
        } else {
          return of(products);
        }
      }),
      switchMap((products) => {
        const updatedPlaceIndex = products.findIndex(pl => pl.id === productId);
        updatedPrpduct = [...products];
        const oldPlace = updatedPrpduct[updatedPlaceIndex];
        updatedPrpduct[updatedPlaceIndex] = new Product(
          oldPlace.id,
          name,
          productNo,
          shortdescription,
          oldPlace.imgUrl,
          loginUserId
        );
        return this.http.put(`https://subscriptionmanagementservice.firebaseio.com/product-details/${productId}.json`,
           {... updatedPrpduct[updatedPlaceIndex] , id: null}
          );
        }),
        tap((resData) => {
        this._places.next(updatedPrpduct);
      }));
  }


  onDeleteProduct(productId: string) {
    return this.http.delete(`https://subscriptionmanagementservice.firebaseio.com/product-details/${productId}.json`
    ).pipe(
      switchMap(() => {
      return this.getProductsDetail;
    }),
      take(1),
      tap(products => {
        this._places.next(products.filter(b => b.id !== productId));
    }));
  }
}

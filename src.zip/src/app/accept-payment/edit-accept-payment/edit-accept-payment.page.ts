import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/new-user/user.model';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from 'src/app/new-user/user-service.service';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { PaymentService } from 'src/app/new-payment/payment.service';
import { AcceptPaymentService } from '../accept-payment.service';
import { LoginService } from 'src/app/login/login.service';
import { DashboardService } from 'src/app/admin-dashboard/dashboard.service';
import { PlanService } from 'src/app/new-plan/plan.service';
import { phoneNumberValidator } from 'src/app/validators/phone-validator';

@Component({
  selector: 'app-edit-accept-payment',
  templateUrl: './edit-accept-payment.page.html',
  styleUrls: ['./edit-accept-payment.page.scss'],
})
export class EditAcceptPaymentPage implements OnInit {
  userId: any;
  user: User;
  private subscriptionObj: Subscription;
  form: FormGroup;
  isLoading = false;
  paymentList: any;
  PlanList: any;
  isDisabled: boolean;
  nextAmountGlob: any;
  nextDateGlob: any;
  checkBoxGlob: string;
  isUpdate: boolean;
  nextFetchAmountGlob: any;
  nextFetchDateGlob: any;
  updateUserId: any;

  constructor(private route: ActivatedRoute,
              private userService: UserServiceService,
              private navCtrl: NavController,
              private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private paymentService: PaymentService,
              private acceptPaymentService: AcceptPaymentService,
              private loginService: LoginService,
              private dashboardService: DashboardService,
              private plnService: PlanService,
              private formBuilder: FormBuilder,
              private acceptService: AcceptPaymentService

) { }

  ngOnInit() {

    this.subscriptionObj = this.paymentService.getPaymentDetails
    .subscribe(paymentList => {
        console.log('paymentList ' + JSON.stringify(paymentList));
        this.paymentList = paymentList;
    });

    this.subscriptionObj = this.plnService.getPlansDetail
    .subscribe(planList => {
        console.log('PlanList ' + JSON.stringify(planList));
        this.PlanList = planList;
    });

    this.route.paramMap.subscribe(paramMap => {

      this.isLoading = true;
      if (!paramMap.has('userPayId') && !paramMap.has('userPayIdOne') && !paramMap.has('userPayIdSecond')) {
        console.log('Not Found..');
        return;
      }
      if (paramMap.has('userPayId')) {
        console.log('userPayId..');
        this.userId = paramMap.get('userPayId');
        this.nextFetchAmountGlob = null;
        this.nextFetchDateGlob = null;
        this.isUpdate = false;

      } else if ( paramMap.has('userPayIdOne') && paramMap.has('userPayIdSecond')) {
            console.log( paramMap.get('userPayIdOne'));
            console.log( paramMap.get('userPayIdSecond'));
            this.userId = paramMap.get('userPayIdOne');
            this.updateUserId = paramMap.get('userPayIdSecond');
            this.isUpdate = true;
            this.subscriptionObj = this.acceptService.getSingleAcceptDetail(paramMap.get('userPayIdSecond')).subscribe(acceptPayModel => {
            this.nextFetchAmountGlob = acceptPayModel.userNextDueAmount;
            this.nextFetchDateGlob =  acceptPayModel.userNextDueDate;
           });

      }
      console.log('this.userPayId ' + this.userId);
      this.subscriptionObj = this.userService.getSingleUserDetail(this.userId)
      .subscribe(
        user => {
          this.isDisabled = false;
          this.form = this.formBuilder.group({
            userName: [user.userName, [
              Validators.required
            ]],
            userPaymentMode: [user.userPaymentMode, [
              Validators.required
            ]],
            userPlanMode: [user.userPlan, [
              Validators.required
            ]],
            payAmount: [this.nextFetchAmountGlob, [
              Validators.required,
              phoneNumberValidator
            ]],
            transId: [null, [

            ]],
            nextDuedate: [null, [
            ]],
            nextDueAmount: [null, [
              phoneNumberValidator
            ]],
            checkBoxMark: [null,[
            ]],
          });

          this.isLoading = false;
        },
        error => {
          this.alertCtrl
            .create({
              header: 'An error occurred!',
              message: 'User Detail could not be fetched. Please try again later.',
              buttons: [
                {
                  text: 'Okay',
                  handler: () => {
                   this.router.navigate(['/admin-dashboard']);
                  }
                }
              ]
            })
            .then(alertEl => {
              alertEl.present();
            });
        }
      );
    });
  }

  get payAmount() {
    return this.form.get('payAmount');
  }
  get nextDuedate() {
    return this.form.get('nextDuedate');
  }
  get nextDueAmount() {
    return this.form.get('nextDueAmount');
  }

  acceptPayment() {
    if (!this.isUpdate) {
       console.log('call add Accept Pay');
       this.acceptPaymentAdd();
    } else {
       console.log('call Update Accept Pay');
       this.updatePayment();
    }
  }

  updatePayment() {
    console.log(this.form.value);
    if ( !this.form.valid) {
      return;
    }

    if (this.form.get('checkBoxMark').value) {
      this.nextAmountGlob = 'N|A';
      this.nextDateGlob   = 'N|A';
      this.checkBoxGlob   = 'true';
    } else {
      this.nextAmountGlob = this.form.value.nextDueAmount;
      this.nextDateGlob =  this.form.value.nextDuedate;
      this.checkBoxGlob = 'false';
    }

    this.loadingCtrl
    .create({
      message: ' Payment made...'
    })
    .then(loadingEl => {
      loadingEl.present();
      this.acceptPaymentService.updateAcceptPayment(
          this.updateUserId,
          this.form.value.userName,
          this.form.value.userPaymentMode,
          this.form.value.userPlanMode,
          this.form.value.payAmount,
          this.form.value.transId,
          this.nextDateGlob,
          this.nextAmountGlob,
          this.checkBoxGlob,
          this.userId,
          this.form.value.payAmount,
          this.loginService.login()
        )
        .subscribe(() => {
          this.dashboardService.addDashBoardBarChartData_SECOND();
          loadingEl.dismiss();
          this.form.reset();
          this.router.navigate(['/accept-payment']);
        });
    });
  }

  acceptPaymentAdd() {
    console.log(this.form.value);
    if ( !this.form.valid) {
      return;
    }

    if (this.form.get('checkBoxMark').value) {
      this.nextAmountGlob = 'N|A';
      this.nextDateGlob   = 'N|A';
      this.checkBoxGlob   = 'true';
    } else {
      this.nextAmountGlob = this.form.value.nextDueAmount;
      this.nextDateGlob =  this.form.value.nextDuedate;
      this.checkBoxGlob = 'false';
    }

    this.loadingCtrl
    .create({
      message: ' Payment made...'
    })
    .then(loadingEl => {
      loadingEl.present();
      this.acceptPaymentService.addNewAcceptPayment(
          this.form.value.userName,
          this.form.value.userPaymentMode,
          this.form.value.userPlanMode,
          this.form.value.payAmount,
          this.form.value.transId,
          this.nextDateGlob,
          this.nextAmountGlob,
          this.checkBoxGlob,
          this.userId,
          this.form.value.payAmount,
          this.loginService.login()
        )
        .subscribe(() => {
          this.dashboardService.addDashBoardBarChartData_SECOND();
          loadingEl.dismiss();
          this.form.reset();
          this.router.navigate(['/accept-payment']);
        });
    });
  }

  check() {
      console.log(this.form.get('checkBoxMark').value);
      if ( this.form.get('checkBoxMark').value ) {
       this.isDisabled = true;
      } else {
        this.isDisabled = false;
      }
  }

}

import { Injectable } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';
import { AcceptPayment } from './accept-payment.model';
import { HttpClient } from '@angular/common/http';
import { LoginService } from '../login/login.service';
import { map, tap, switchMap, take } from 'rxjs/operators';

interface AcceptPaymentInterface {
   id: string;
   userName: string;
   userPaymentMode: string;
   userPlanMode: string;
   payAmount: string;
   transId: string;
   userNextDueDate: Date;
   userNextDueAmount: string;
   checkBox: string;
   userDetailUserId: string;
   totalAmount: any;
   loginUserId: string;
}


@Injectable({
  providedIn: 'root'
})
export class AcceptPaymentService {

  private acceptPaymentBehaviourObj = new BehaviorSubject<AcceptPayment[]>([
    // new Payment('0' , 'Cash'            , 'Payment Done by cash mode'),
    // new Payment('1' , 'Demand Draft'    , 'Payment Done by DD')
  ]);

  get getAcceptPaymentDetails() {
    return this.acceptPaymentBehaviourObj.asObservable();
  }

  constructor(private http: HttpClient ,
              private loginService: LoginService) { }

  fetchAcceptPayment(userId: string) {
    // tslint:disable-next-line: max-line-length
    return this.http.get<{[key: string]: AcceptPayment}>(`https://subscriptionmanagementservice.firebaseio.com/acceptPayment-details.json?orderBy="loginUserId"&equalTo=${userId}`)
    .pipe(map(resData => {
      console.log(resData);
      const acceptPaymentArray = [];
      for (const key in resData) {
          if ( resData.hasOwnProperty(key)) {
            acceptPaymentArray.push(new AcceptPayment(
              key,
              resData[key].userName,
              resData[key].userPaymentMode,
              resData[key].userPlanMode,
              resData[key].payAmount,
              resData[key].transId,
              resData[key].userNextDueDate,
              resData[key].userNextDueAmount,
              resData[key].checkBox,
              resData[key].userDetailUserId,
              resData[key].totalAmount,
              resData[key].loginUserId
              ));
          }
        }
      return acceptPaymentArray;
    }),
    tap(resArrayFromMap => {
      this.acceptPaymentBehaviourObj.next(resArrayFromMap);
      })
    );
  }

  getSingleAcceptDetail(id: string) {
    //  return this.getPlansDetail.pipe(
    //    take(1),
    //    map(plan => {
    //      return { ...plan.find(p => p.id === id) };
    //    })
    //  );
    return this.http.get<AcceptPaymentInterface>(`https://subscriptionmanagementservice.firebaseio.com/acceptPayment-details/${id}.json`
    ).pipe(
      // tslint:disable-next-line: no-shadowed-variable
      map(AcceptPaymentForOne => {
        return new AcceptPayment (
            id,
            AcceptPaymentForOne.userName,
            AcceptPaymentForOne.userPaymentMode,
            AcceptPaymentForOne.userPlanMode,
            AcceptPaymentForOne.payAmount,
            AcceptPaymentForOne.transId,
            new Date(AcceptPaymentForOne.userNextDueDate),
            AcceptPaymentForOne.userNextDueAmount,
            AcceptPaymentForOne.checkBox,
            AcceptPaymentForOne.userDetailUserId,
            AcceptPaymentForOne.totalAmount,
            AcceptPaymentForOne.loginUserId
          );
        })
      );
    }

  addNewAcceptPayment(
                      acceptPaymentUserName: string ,
                      acceptPaymentMode: string ,
                      acceptPlanMode: string ,
                      payAmount: string,
                      transId: string,
                      acceptnextDuedate: Date,
                      acceptnextDueAmount: string,
                      checkBox: string,
                      userDetailUserId: string,
                      totalAmount: any,
                      userId: string) {
    const newPayment = new AcceptPayment(
    Math.random().toString(),
    acceptPaymentUserName,
    acceptPaymentMode,
    acceptPlanMode,
    payAmount,
    transId,
    acceptnextDuedate,
    acceptnextDueAmount,
    checkBox,
    userDetailUserId,
    totalAmount,
    userId
    );
    let generatedId: string;
    console.log('newPayment : ' + JSON.stringify(newPayment));
    // tslint:disable-next-line: max-line-length
    return this.http.post<{name: string}>('https://subscriptionmanagementservice.firebaseio.com/acceptPayment-details.json', {...newPayment , id: null})
           .pipe(
              switchMap(resData => {
                generatedId = resData.name;
                return this.getAcceptPaymentDetails;
              }),
              take(1),
              tap(plan => {
                  console.log(' this._places 1 : ');
                  newPayment.id =  generatedId;
                  this.acceptPaymentBehaviourObj.next(plan.concat(newPayment));
               })
           );

  }


  updateAcceptPayment(
    acceptId: string,
    acceptPaymentUserName: string ,
    acceptPaymentMode: string ,
    acceptPlanMode: string ,
    payAmount: string,
    transId: string,
    acceptnextDuedate: Date,
    acceptnextDueAmount: string,
    checkBox: string,
    userDetailUserId: string,
    totalAmount: any,
    userId: string
    ) {
    let updatedPlan: AcceptPayment[];
    return this.acceptPaymentBehaviourObj.pipe(
       take(1),
       switchMap(plan => {
        if ( !plan || plan.length <= 0) {
          return this.fetchAcceptPayment(userId);
        } else {
          return of(plan);
        }
      }),
      switchMap((plans) => {
        const updatedPlaceIndex = plans.findIndex(pl => pl.id === acceptId);
        updatedPlan = [...plans];
        const oldPlan = updatedPlan[updatedPlaceIndex];
        updatedPlan[updatedPlaceIndex] = new AcceptPayment(
          oldPlan.id,
          acceptPaymentUserName ,
          acceptPaymentMode ,
          acceptPlanMode ,
          payAmount,
          transId,
          acceptnextDuedate,
          acceptnextDueAmount,
          checkBox,
          userDetailUserId,
          // tslint:disable-next-line: radix
          parseInt(oldPlan.totalAmount) + parseInt(totalAmount),
          userId
        );
        return this.http.put(`https://subscriptionmanagementservice.firebaseio.com/acceptPayment-details/${acceptId}.json`,
           {... updatedPlan[updatedPlaceIndex] , id: null}
          );
        }),
        tap((resData) => {
        this.acceptPaymentBehaviourObj.next(updatedPlan);
      }));
   }

}

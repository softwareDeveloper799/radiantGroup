import { Component, OnInit, OnDestroy } from '@angular/core';
import { SegmentChangeEventDetail } from '@ionic/core';
import { UserServiceService } from '../new-user/user-service.service';
import { PaymentService } from '../new-payment/payment.service';
import { Subscription } from 'rxjs';
import { LoginService } from '../login/login.service';
import { AcceptPaymentService } from './accept-payment.service';
import { PlanService } from '../new-plan/plan.service';

@Component({
  selector: 'app-accept-payment',
  templateUrl: './accept-payment.page.html',
  styleUrls: ['./accept-payment.page.scss'],
})

export class AcceptPaymentPage implements OnInit , OnDestroy{
  isLoading = false;
  userList: any;
  userPaymentList: any;
  private subscriptionObj: Subscription;
  segmentSelection: boolean;
  selectedSegment: any;

  constructor(private userService: UserServiceService,
              private paymentService: PaymentService,
              private loginService: LoginService,
              private acceptPaymentService: AcceptPaymentService,
              private planService: PlanService
    ) { }

  ngOnInit() {
    this.subscriptionObj = this.userService.getUsersDetails
        .subscribe(userDetails => {
            console.log('userDetails ' + JSON.stringify(userDetails));
            this.segmentSelection = true;
            this.userList = userDetails;
        });

    this.subscriptionObj = this.acceptPaymentService.getAcceptPaymentDetails
         .subscribe(acceptPaymentList => {
             console.log('userPaymentList ' + JSON.stringify(acceptPaymentList));
             this.userPaymentList = acceptPaymentList;
         });
  }

  ionViewWillEnter() {
     this.isLoading = true;
     this.userService.fetchUserList(this.loginService.login()).subscribe(() => {
      this.paymentService.fetchPayment(this.loginService.login()).subscribe(() => {
        this.planService.fetchPlan(this.loginService.login()).subscribe(() => {
          this.acceptPaymentService.fetchAcceptPayment(this.loginService.login()).subscribe(() => {
            this.isLoading = false;
            this.selectedSegment = `user-list`;
          });
        });
      });
     });
 }

  onFilterUpdate(event: CustomEvent<SegmentChangeEventDetail>) {
    if (event.detail.value === 'user-list') {
      this.segmentSelection = true;
    } else {
      this.segmentSelection = false;
    }
  }

  onedit(user: any , slidingItem) {
    console.log('OnEdit :: ' + JSON.stringify(user));
    slidingItem.close();
  }

  ondelete(user: any ,  slidingItem) {
   console.log('OnDelete :: ' + JSON.stringify(user));
   slidingItem.close();
  }

  ngOnDestroy() {
    if (this.subscriptionObj ) {
        this.subscriptionObj.unsubscribe();
    }
  }

}

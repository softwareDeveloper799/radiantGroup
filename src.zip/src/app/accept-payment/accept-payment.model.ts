
export class AcceptPayment {
    constructor(
      public id: string,
      public userName: string,
      public userPaymentMode: string,
      public userPlanMode: string,
      public payAmount: string,
      public transId: string,
      public userNextDueDate: Date,
      public userNextDueAmount: string,
      public checkBox: string,
      public userDetailUserId: string,
      public totalAmount: any,
      public loginUserId: string
    ) {}
  }

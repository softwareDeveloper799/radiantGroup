import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { AcceptPaymentPage } from './accept-payment.page';

const routes: Routes = [
  {
    path: '',
    component: AcceptPaymentPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [AcceptPaymentPage],
  entryComponents: []
})
export class AcceptPaymentPageModule {}

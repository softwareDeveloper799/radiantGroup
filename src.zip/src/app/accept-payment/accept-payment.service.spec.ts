import { TestBed } from '@angular/core/testing';

import { AcceptPaymentService } from './accept-payment.service';

describe('AcceptPaymentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AcceptPaymentService = TestBed.get(AcceptPaymentService);
    expect(service).toBeTruthy();
  });
});

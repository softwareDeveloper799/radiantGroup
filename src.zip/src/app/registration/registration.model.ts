export class RegisterUser {
  firstName: string;
  lastName: string;
  mobileNumber: string;
  password: string;
}

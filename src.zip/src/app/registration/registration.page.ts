import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { phoneNumberValidator } from '../validators/phone-validator';
import { RegistrationService } from '../registration.service';
import { LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.page.html',
  styleUrls: ['./registration.page.scss'],
})
export class RegistrationPage implements OnInit {

  form: FormGroup;
  value: number;
  constructor(private formBuilder: FormBuilder,
              private registerService: RegistrationService,
              private loadingCtrl: LoadingController,
              private router: Router) { }

  ngOnInit() {

    this.form = this.formBuilder.group({
      firstName: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern('^[a-zA-Z ]+$')
      ]],
      lastName: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern('^[a-zA-Z ]+$')
      ]],
      mobileNumber: ['', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        phoneNumberValidator
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(8),
      ]],
    });

    //  this.form = new FormGroup({
    //   firstName: new FormControl(null, {
    //     updateOn: 'blur',
    //     validators: [Validators.required]
    //   }),
    //   lastName: new FormControl(null, {
    //     updateOn: 'blur',
    //     validators: [Validators.required]
    //   }),
    //   mobileNumber: new FormControl(null, {
    //     updateOn: 'blur',
    //     validators: [Validators.required , Validators.minLength(10) , phoneNumberValidator]
    //   }),
    //   password: new FormControl(null, {
    //     updateOn: 'blur',
    //     validators: [Validators.required , Validators.minLength(6)]
    //   })
    // });

    // this.form = this.fb.group({
    //   mobileNumber:  this.fb.control('', [Validators.required, phoneNumberValidator]),
    // });
  }

  get firstName() {
    return this.form.get('firstName');
  }
  get lastName() {
    return this.form.get('lastName');
  }
  get mobileNumber() {
    return this.form.get('mobileNumber');
  }
  get password() {
    return this.form.get('password');
  }

  onRegistration() {
    console.log(this.form.get('firstName'));
    if (!this.form.valid) {
      alert('invalid');
      return;
    }
    // tslint:disable-next-line: radix
    this.value = parseInt(this.form.value.mobileNumber);
    const obj = {
      firstName: this.form.value.firstName,
      lastName: this.form.value.lastName,
      mobileNumber: this.value,
      password: this.form.value.password
    }
    console.log(this.form.value);

    this.loadingCtrl
    .create({
      message: 'Register please wait...'
    })
    .then(loadingEl => {
        loadingEl.present();
        this.registerService.registerUserService(obj).subscribe(() => {
          this.router.navigate(['/login'], { replaceUrl: true });
          loadingEl.dismiss();
          this.form.reset();
        });
    });
  }

}

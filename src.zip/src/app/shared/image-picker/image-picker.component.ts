import { Component, OnInit, Output, EventEmitter, Input , ChangeDetectorRef } from '@angular/core';
import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { ActionSheetController } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';

@Component({
  selector: 'app-image-picker',
  templateUrl: './image-picker.component.html',
  styleUrls: ['./image-picker.component.scss'],
})
export class ImagePickerComponent implements OnInit {

  selectedImage = null; //'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Paris_Night.jpg/1024px-Paris_Night.jpg';

  @Output() imagePick = new EventEmitter<string | File>();
  @Input() showPreview = false;

  constructor(  private camera: Camera,
                private actionSheetCtrl: ActionSheetController,
                private imagePicker: ImagePicker,
                private changeRef: ChangeDetectorRef
    ) { }

  ngOnInit() {

  }

  onPickImage() {
    this.actionSheetCtrl
    .create({
      header: 'Choose an Action',
      buttons: [
        {
          text: ' Open Camera',
          handler: () => {
            const options: CameraOptions = {
              quality: 75,
              destinationType: this.camera.DestinationType.DATA_URL,
              encodingType: this.camera.EncodingType.JPEG,
              mediaType: this.camera.MediaType.PICTURE,
              saveToPhotoAlbum: true,
              targetHeight: 225,
              targetWidth: 225,
              correctOrientation: true,
            };
            this.camera.getPicture(options).then((imageData) => {
              console.log(imageData);
              this.selectedImage = 'data:image/jpeg;base64,' + imageData;
              console.log('imageData call' + this.selectedImage );
              this.changeRef.detectChanges();
              this.imagePick.emit(imageData);
            }, (error) => {
              console.log('ERROR CAMERA :: ');
              console.log(error);
              return false;
            });
          }
        },
        // {
        //   text: 'Open Gallary',
        //   handler: () => {
        //     const options = {
        //       quality: 100,
        //       maximumImagesCount: 1,
        //       outputType: 1
        //     };
        //     this.imagePicker.getPictures(options).then((results) => {
        //       // tslint:disable-next-line: prefer-for-of
        //       // implementation(project(path: ":CordovaLib"))
        //       // implementation "com.android.support:support-v4:23.+"
        //       // implementation "com.android.support:support-annotations:27.+"
        //       // implementation "com.android.support:appcompat-v7:23+"
        //       // tslint:disable-next-line: prefer-for-of
        //       for (let i = 0; i < results.length; i++) {
        //         console.log('CHANGES AKSHAY CALL :: ' + results[i]);
        //         console.log('Image URI: ' + results[i]);
        //         this.imagePick.emit(results[i]);
        //       }
        //     }, (err) => {
        //       console.log('ERROR IMAGE PICKER :: ');
        //       console.log(err);
        //     });
        //   }
        // },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    })
    .then(actionSheetEl => {
      actionSheetEl.present();
    });


  }

}

import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'registration', loadChildren: './registration/registration.module#RegistrationPageModule' },
  { path: 'admin-dashboard', loadChildren: './admin-dashboard/admin-dashboard.module#AdminDashboardPageModule' },
  { path: 'new-product', loadChildren: './new-product/new-product.module#NewProductPageModule' },
  { path: 'new-payment', loadChildren: './new-payment/new-payment.module#NewPaymentPageModule' },
  { path: 'new-user', loadChildren: './new-user/new-user.module#NewUserPageModule' },
  { path: 'generate-reports', loadChildren: './generate-reports/generate-reports.module#GenerateReportsPageModule' },
  { path: 'edit-profile', loadChildren: './edit-profile/edit-profile.module#EditProfilePageModule' },
  { path: 'new-plan', loadChildren: './new-plan/new-plan.module#NewPlanPageModule' },
  { path: 'edit-product/:id', loadChildren: './new-product/edit-product/edit-product.module#EditProductPageModule' },
  { path: 'edituser/:userId', loadChildren: './new-user/edituser/edituser.module#EdituserPageModule' },
  { path: 'edit-plan/:id', loadChildren: './new-plan/edit-plan/edit-plan.module#EditPlanPageModule' },
  { path: 'edit-payment/:id', loadChildren: './new-payment/edit-payment/edit-payment.module#EditPaymentPageModule' },
  { path: 'accept-payment', loadChildren: './accept-payment/accept-payment.module#AcceptPaymentPageModule' },
  { path: 'edit-accept-payment/:userPayId', loadChildren: './accept-payment/edit-accept-payment/edit-accept-payment.module#EditAcceptPaymentPageModule' },
  { path: 'edit-accept-payment/:userPayIdOne/:userPayIdSecond', loadChildren: './accept-payment/edit-accept-payment/edit-accept-payment.module#EditAcceptPaymentPageModule' },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {  enableTracing: false, preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, ViewChild } from '@angular/core';

import { Platform , MenuController, LoadingController, Events, IonRouterOutlet} from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';
import { LoginService } from './login/login.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {

  userFirstName: any;
  @ViewChild(IonRouterOutlet) routerOutlet: IonRouterOutlet;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private menu: MenuController,
    private router: Router,
    private loadingCtrl: LoadingController,
    private loginService: LoginService,
    private event: Events,
    public alertCtrl: AlertController

  ) {
    this.initializeApp();
    this.event.subscribe('userLogged', (data) => {
      this.userFirstName  = data;
   });

  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      setTimeout(() => {
        this.splashScreen.hide();
        this.statusBar.styleLightContent();
      }, 3000);

      this.platform.backButton.subscribeWithPriority(0, () => {
        if (this.routerOutlet && this.routerOutlet.canGoBack()) {
          this.routerOutlet.pop();
      } else if (this.router.url === '/admin-dashboard' || this.router.url === '/login') {
        this.alertCtrl
        .create({
          header : 'Exit App',
          message: 'Are you Sure you Want to Exit From App?',
          buttons: [
            {
             text: 'OK',
             handler: () => {
               navigator['app'].exitApp();
             }
            },
            {
            text: 'CANCEL',
            handler: () => {
             // navigator['app'].exitApp();
            }
          }
         ],
         backdropDismiss : false
        })
        .then(alertEl => {
          alertEl.present();
        });
      } else {
        console.log('Dashwww');
      }
    });

    });
  }

  openEnd() {
    this.menu.close();
  }

  logout() {
    this.loadingCtrl
    .create({
      message: 'please wait...'
    })
    .then(loadingEl => {
      loadingEl.present();
      this.loginService.onlogout();
      this.router.navigate(['/login'], { replaceUrl: true });
      loadingEl.dismiss();
    });
  }
}

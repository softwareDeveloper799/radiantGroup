import { Injectable, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, of, Observable } from 'rxjs';
import { take, map, tap, delay, switchMap, isEmpty } from 'rxjs/operators';
import { LoginUserData } from './login.model';
import { Events } from '@ionic/angular';

interface LoginData {
  firstName: string;
  lastName: string;
  mobileNumber: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class LoginService {

 // @Output() public title: string;
 // @Output() title = new EventEmitter<string>();

  private userId = null;
  private firstNameValue = null;
  private userBehaviourObj = new BehaviorSubject<LoginUserData[]>([]);

  constructor(private http: HttpClient, private event: Events) {}

  login() {
    return this.userId;
  }
  onlogout() {
    this.userId = null;
  }

  firstName() {
    return this.firstNameValue;
  }

  get getLoginUserDetail() {
    return this.userBehaviourObj.asObservable();
  }

  OnloginUserService(userMobileNmber: number , userPassword: string) {
    console.log(`userMobileNmber :: ${userMobileNmber} userPassword :: ${userPassword} `);
     // tslint:disable-next-line: max-line-length
    return this.http.get<{ LoginData }>(`https://subscriptionmanagementservice.firebaseio.com/registration-details.json?orderBy="mobileNumber"&equalTo=${userMobileNmber}`)
    .pipe(
      map(logindata => {
        console.log(logindata);
        const loginArray = [];
        for (const key in logindata) {
          if (logindata.hasOwnProperty(key)) {

            console.log(logindata);
            console.log(logindata[key].firstName);

            if ( logindata[key].password !== userPassword ) {
              loginArray.push(
                new LoginUserData(
                logindata[key].firstName,
                logindata[key].lastName,
                logindata[key].mobileNumber,
                'Wrong Password'
              ));
            } else {
              loginArray.push(
                new LoginUserData(
                logindata[key].firstName,
                logindata[key].lastName,
                logindata[key].mobileNumber,
                logindata[key].password,
              ));
            }
          }
        }
        return loginArray;
      }),
      take(1),
      tap(logindataArray => {

        console.log(logindataArray);
        if ( logindataArray.length === 0) {
         logindataArray.push( new LoginUserData(
          'Empty',
          'Empty',
          'Empty',
          'Empty'
          ));
        } else {
          this.firstNameValue = logindataArray[0].firstName;
          this.userId = logindataArray[0].mobileNumber;
          this.event.publish('userLogged', this.firstNameValue);
        //  this.title.emit(this.firstNameValue);
        }

        this.userBehaviourObj.next(logindataArray);
      })
    );
  }

}

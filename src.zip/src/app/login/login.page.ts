import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators , FormBuilder } from '@angular/forms';
import { LoadingController, AlertController,MenuController  } from '@ionic/angular';
import { LoginService } from './login.service';
import { Subscription } from 'rxjs';
import { phoneNumberValidator } from '../validators/phone-validator';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  form: FormGroup;
  userFirstName: any;
  userMobile: number;
  private subscriptionObj: Subscription;

  constructor(private router: Router,
              private formBuilder: FormBuilder,
              private loadingCtrl: LoadingController,
              private loginService: LoginService,
              private alertCtrl: AlertController,
              private menuController: MenuController
              ) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      mobileNumber: [null, [
        Validators.required,
        // Validators.minLength(10),
        // Validators.maxLength(10),
        // phoneNumberValidator
      ]],
      password: [null, [
        Validators.required,
        Validators.minLength(4)
      ]],
    });
  }

  ionViewDidEnter() {
    this.menuController.enable(false);
}

ionViewDidLeave() {
    this.menuController.enable(true);
}

   get mobileNumber() {
      return this.form.get('mobileNumber');
   }
   get password() {
    return this.form.get('password');
   }

  onLogin() {

      console.log(this.form.get('mobileNumber'));
      this.userMobile = this.form.value.mobileNumber;
      const userPassword = this.form.value.password;

      this.loadingCtrl
          .create({
            message: 'Login please wait...'
          })
          .then(loadingEl => {
            loadingEl.present();
            this.subscriptionObj = this.loginService.OnloginUserService(this.userMobile, userPassword ).subscribe((res) => {
               console.log(res);
               if (res[0].hasOwnProperty('password')) {

                 if (res[0].firstName === 'Empty') {
                  loadingEl.dismiss();
                  this.alert('User Name Password Not Exist !!');
                  this.form.reset();
                  return;
                 }
                 if (res[0].password === 'Wrong Password') {
                    loadingEl.dismiss();
                    this.alert('Invalid Password ');
                  } else {
                    this.userFirstName = res[0].firstname;
                    this.router.navigate(['/admin-dashboard'], { replaceUrl: true });
                    loadingEl.dismiss();
                    this.form.reset();
                  }
                } else {
                  loadingEl.dismiss();
                  this.alert('Opps Something Went Wront Pleaase try Again !');
                  this.form.reset();
                }
            } ,
            error => {
              loadingEl.dismiss();
              this.alertCtrl
                .create({
                  header: 'An error occurred!',
                  message: 'Check your Internet Connection and try again!',
                  buttons: [
                    {
                      text: 'Okay',
                      handler: () => {
                      }
                    }
                  ]
                })
                .then(alertEl => {
                  alertEl.present();
                });
            });
        });
  }


  alert(str: string) {
    this.alertCtrl
    .create({
      header : 'Login Failed',
      message: str,
      buttons: [
        {
         text: 'OK',
         handler: () => {
          // navigator['app'].exitApp();
         }
       }
     ],
     backdropDismiss : false
    })
    .then(alertEl => {
      alertEl.present();
    });
  }

}

export class LoginUserData {
    constructor(
      public firstName: string,
      public lastName: string,
      public mobileNumber: string,
      public password: string
    ) {}
  }
